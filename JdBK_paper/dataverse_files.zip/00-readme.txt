## Replication File for:
## ``Persuading the Enemy: Estimating the Persuasive Effects of Partisan Media with the Preference-Incorporating Choice and Assignment Design"
## Justin de Benedictis-Kessner, Matthew A. Baum, Adam J. Berinsky, and Teppei Yamamoto

These replication materials provide code and data to reproduce all analyses, tables, and figures from the paper and appendix. The main results in the paper come from the survey conducted via SSI in December 2017

Script files are in numbered order for clarity. Their purpose is as follows:

01-survey_recodes.R takes the raw survey dataset (MediaChoiceFall2017_full.csv), recodes variables, and outputs a new recoded dataset (MediaSSI_Dec2017_recoded.csv) used by the other scripts.

02-main_tables_figures.R contains code to produce all tables in the appendix as well as many numbers reported throughout the text and appendix. It also produces Figures 2, 4, and 5.

03-sensitivity_analyses.R contains code that runs bounds and sensitivity analyses, as well as produces Figures 3 and 6.

04-ssi_isis_figure.R contains code to ingest the recoded dataset from the SSI 2015 ISIS experiment and produce Figure E-1.

05-ssi_fracking_figure.R contains code to ingest the recoded dataset from the SSI 2014 fracking experiment and produce Figure E-2.

06-comscore_education_figure.R contains code to ingest the recoded dataset from the comScore 2018 education policy experiment and produce Figure E-3.

bounds_frechet_function.R contains the functions necessary to compute bounds and run the sensitivity analyses.