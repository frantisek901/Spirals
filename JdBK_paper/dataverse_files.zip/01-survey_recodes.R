## Replication File for:
## ``Persuading the Enemy: Estimating the Persuasive Effects of Partisan Media with the Preference-Incorporating Choice and Assignment Design"
## Justin de Benedictis-Kessner, Matthew A. Baum, Adam J. Berinsky, and Teppei Yamamoto


## ---------- ##
#### Notes: ####
## ---------- ##

# This is the first script file needed to reproduce the results from the paper
# Run this script first to produce recoded survey dataset that subsequent scripts need
# Other scripts will produce the tables and figures that represent the main results

## --------------------- ##
#### Preliminary stuff ####
## --------------------- ##

library(tidyverse)
library(car)


## ------------------- ##
#### Read in SSI data: ####
## ------------------- ##
## From November 2017 survey launch via SSI
w1 <- read_csv("MediaChoiceFall2017_full.csv")[-c(1,2),]
w1$PID[w1$PID==""] <- NA
w1$psid[w1$psid==""] <- NA
w1 <- w1[which(!is.na(w1$psid) & !is.na(w1$PID)),]

## ---------- ##
### Recodes ####
## ---------- ##

# forced vs. free choice:
table(w1$forcedchoice) # 1=forced, forced; 2 = forced, free; 3 = free, free; and 4=free, forced 
w1$forced_pattern <- w1$forcedchoice
w1$forcedchoice <- ifelse(w1$forced_pattern %in% c(1,2),1,0)
table(w1$forcedchoice)

# Media preference:
table(w1$med_pref) # 1=MSNBC, 2=Fox, 3=Food Network
w1$med_pref <- car::recode(as.numeric(w1$med_pref),"1='MSNBC';2='Fox';3='Entertainment'")
table(w1$med_choice[w1$forcedchoice==0]) # 1=MSNBC, 2=Fox, 3=Food Network
w1$med_choice <- car::recode(as.numeric(w1$med_choice),"1='MSNBC';2='Fox';3='Entertainment';else=NA")

crosstab(w1$med_choice,w1$med_pref,prop.c = T,plot = F)

# Forced choice:
w1$msnbc <- ifelse(w1$forcedchoice==1,ifelse(w1$source %in% c(1,2,3),1,0),NA)
w1$fox <- ifelse(w1$forcedchoice==1,ifelse(w1$source %in% c(4,5,6),1,0),NA)
w1$entertainment <- ifelse(w1$forcedchoice==1,ifelse(w1$source %in% c(7,8,9),1,0),NA)

table(w1$msnbc)
table(w1$fox)
table(w1$entertainment)

## article read for forced choice:
w1$article_forced <- ifelse(w1$fox==1,'Fox',
                            ifelse(w1$msnbc==1,'MSNBC',
                                   ifelse(w1$entertainment==1,'Entertainment',NA)))
table(w1$article_forced)

w1$article_read <- ifelse(w1$forcedchoice==1,w1$article_forced,w1$med_choice)
table(w1$article_read)

# Actions:
w1$actions_discuss <- as.numeric(car::recode(w1$actions_actions_discuss,"1=3;2=2;3=1;4=0;7=NA"))/3
w1$actions_forward <- as.numeric(car::recode(w1$actions_actions_forward,"1=3;2=2;3=1;4=0;7=NA"))/3
w1$actions_post <- as.numeric(car::recode(w1$actions_actions_post,"1=3;2=2;3=1;4=0;7=NA"))/3
w1$actions_seek <- as.numeric(car::recode(w1$actions_actions_4,"1=3;2=2;3=1;4=0;7=NA"))/3
w1$actions_index <- apply(w1[,c("actions_discuss","actions_forward","actions_post","actions_seek")],1,mean,na.rm=T) # though this excludes NA from NS responses
summary(w1$actions_index)

# Manipulation checks
w1$mc_legalization <- (as.numeric(w1$Q167)-1)/4 # 1 oppose - 5 support --> supportive=1, opposed=0
w1$mc_grocery <- (as.numeric(w1$Q246)-1)/4 # 1 oppose - 5 support --> supportive=1, opposed=0
w1$mc_eff <- (as.numeric(w1$Q168)-1)/4 # 1=def effective, 0=def not effective
w1$mc_legalization_understand <- (4-as.numeric(w1$Q169))/3 # 1=very well, 0=not at all
w1$mc_grocery_understand <- (4-as.numeric(w1$Q247))/3 # 1=very well, 0=not at all
w1$mc_ideo <- (as.numeric(w1$Q170)-1)/6 # 1=extremely conservative, 0= extremely liberal

crosstab(w1$mc_legalization,w1$article_forced,prop.c=T) # looks like this is working
crosstab(w1$mc_grocery,w1$article_forced,prop.c=T) # pretty middle-of-the-road
crosstab(w1$mc_ideo,w1$article_forced,prop.c=T) # also working

# Story traits (coded with positive attribute = 1, negative attribute = 0)
w1$story_fair <- (7-as.numeric(w1$fair_4))/6 # 1=very fair, 0=very unfair
w1$story_friendly <- (7-as.numeric(w1$friendly_4))/6 # 1=very friendly, 0=very hostile
w1$story_good <- (7-as.numeric(w1$good_4))/6 # 1=very good, 0=very bad
w1$story_quarrel <- (as.numeric(w1$quarrel_4)-1)/6 # 1=very cooperative, 0=very quarrelsome
w1$story_balanced <- (7-as.numeric(w1$balanced_4))/6 # 1=very balanced, 0=very skewed
w1$story_oneside <- (as.numeric(w1$oneside_4)-1)/6 # 1=very even-handed, 0=very one-sided
w1$story_american <- (7-as.numeric(w1$american_4))/6 # 1=very american, 0=very un-american
w1$story_accurate <- (7-as.numeric(w1$accurate_4))/6 # 1=very accurate, 0=very inaccurate

# trust in media/ hostile media scale
w1$trust_1 <- as.numeric(w1$trust_1) # newspaper reporters
w1$trust_2 <- as.numeric(w1$trust_2) # newspaper columnists
w1$trust_3 <- as.numeric(w1$trust_3) # TV news reporters
w1$trust_4 <- as.numeric(w1$trust_4) # TV news commentators
w1$hmedia <- NULL
for(i in 1:nrow(w1)){
      w1$hmedia[i] <- ifelse(!is.na(w1$trust_1[i]+w1$trust_2[i]+w1$trust_3[i]+w1$trust_4[i]),
                             (w1$trust_1[i]-1+w1$trust_2[i]-1+w1$trust_3[i]-1+w1$trust_4[i]-1)/12,NA)
}
table(w1$hmedia)/sum(table(w1$hmedia)) # 1= most hostile, 0= least hostile to media

# Issue grids: recoding all to strongly agree=1, strongly disagree=0
w1$nafta_USMex <- (7-as.numeric(w1$issue_grid1_1))/6
w1$mar_costmore <- (7-as.numeric(w1$issue_grid1_2))/6
w1$justice_biased <- (7-as.numeric(w1$issue_grid1_3))/6
w1$trust_police <- (7-as.numeric(w1$issue_grid1_4))/6
w1$mar_fewserious <- (7-as.numeric(w1$issue_grid1_5))/6
w1$trade_hurtsjobs <- (7-as.numeric(w1$issue_grid1_6))/6

w1$mar_wrong <- (7-as.numeric(w1$issue_grid2_1))/6
w1$trade_fewrestr <- (7-as.numeric(w1$issue_grid2_3))/6
w1$mar_violence <- (7-as.numeric(w1$issue_grid2_4))/6
w1$imm_crime <- (7-as.numeric(w1$issue_grid2_5))/6
w1$nafta_CanUS <- (7-as.numeric(w1$issue_grid2_6))/6
w1$mar_legmed <- (7-as.numeric(w1$issue_grid2_7))/6
w1$sentences_mand <- (7-as.numeric(w1$issue_grid2_8))/6

w1$mar_serious <- (7-as.numeric(w1$issue_scnr_grid3_1))/6
w1$scr_ww1_pass <- ifelse(w1$issue_scnr_grid3_2==7,1,0)
w1$guncontr_reduce <- (7-as.numeric(w1$issue_scnr_grid3_3))/6
w1$mar_legrec <- (7-as.numeric(w1$issue_scnr_grid3_4))/6
w1$deathpen <- (7-as.numeric(w1$issue_scnr_grid3_5))/6
w1$trade_growth <- (7-as.numeric(w1$issue_scnr_grid3_6))/6
w1$trade_hurtsfam <- (7-as.numeric(w1$issue_scnr_grid3_7))/6

w1$grocery_deals <- (7-as.numeric(w1$grocery_scnr_grid_1))/6
w1$grocery_notfam <- (7-as.numeric(w1$grocery_scnr_grid_2))/6
w1$grocery_online <- (7-as.numeric(w1$grocery_scnr_grid_3))/6
w1$grocery_resp <- (7-as.numeric(w1$grocery_scnr_grid_4))/6
w1$scr_obama_pass <- ifelse(w1$grocery_scnr_grid_5==7,1,0)
w1$grocery_nolist <- (7-as.numeric(w1$grocery_scnr_grid_6))/6


# Specific Marijuana DVs: recoding all to conservative response=1, liberal=0 if possible
w1$mar_tradeoff <- car::recode(as.numeric(w1$Q178),"6=0;5=1;4=2;3=3;2=4;8=5;1=6")/6 # criminal offense=1, addiction problem=0
w1$mar_econ <- (as.numeric(w1$Q184)-1)/4 # econ much worse=1, econ much better=0
w1$mar_costmore <- 1-w1$mar_costmore # now agree strongly=0, disagree strongly=1
w1$mar_fewserious <- 1-w1$mar_fewserious # now agree strongly=0, disagree strongly=1
w1$mar_wrong <- w1$mar_wrong # coded correctly, agreement that morally wrong=1
w1$mar_violence <- w1$mar_violence # coded correctly, agreement that increases violent crime=1
w1$mar_legmed <- 1-w1$mar_legmed # now agree strongly=0, disagree strongly=1
w1$mar_serious <- w1$mar_serious # coded correctly, agreement that serious problem=1
w1$mar_legrec <- 1-w1$mar_legrec # now agree strongly=0, disagree strongly=1


# Danger of drugs:
w1$danger_heroin <- (5-as.numeric(w1$Q175_1))/4 # 1=very dangerous, 0=very safe
w1$danger_tobacco <- (5-as.numeric(w1$Q175_2))/4 # 1=very dangerous, 0=very safe
w1$danger_alc <- (5-as.numeric(w1$Q175_3))/4 # 1=very dangerous, 0=very safe
w1$danger_mar <- (5-as.numeric(w1$Q175_4))/4 # 1=very dangerous, 0=very safe
w1$danger_cocaine <- (5-as.numeric(w1$Q175_5))/4 # 1=very dangerous, 0=very safe


## Demographics:
# PID and Ideology variables:
w1$pid <- NULL
for(i in 1:nrow(w1)){
  w1$pid[i] <- NA
  w1$pid[i] <- ifelse(w1$party4[i]==3,0,NA)
  w1$pid[i] <- ifelse(w1$party1[i]==1,-1,w1$pid[i])
  w1$pid[i] <- ifelse(w1$party1[i]==2,1,w1$pid[i])
  w1$pid[i] <- ifelse(!is.na(w1$party4[i]),ifelse(w1$party4[i]==1,1,w1$pid[i]),w1$pid[i])
  w1$pid[i] <- ifelse(!is.na(w1$party4[i]),ifelse(w1$party4[i]==2,-1,w1$pid[i]),w1$pid[i])
}
table(w1$pid)/sum(table(w1$pid)) # pretty balanced on PID...

w1$pid7 <- NA
for(i in 1:nrow(w1)){
	w1$pid7[i] <- ifelse(!is.na(w1$party4[i]),ifelse(w1$party4[i]==3,0,w1$pid7[i]),w1$pid7[i]) # true ind
	w1$pid7[i] <- ifelse(!is.na(w1$party4[i]),ifelse(w1$party4[i]==1,1,w1$pid7[i]),w1$pid7[i]) # lean R
	w1$pid7[i] <- ifelse(!is.na(w1$party4[i]),ifelse(w1$party4[i]==2,-1,w1$pid7[i]),w1$pid7[i]) # lean D
	w1$pid7[i] <- ifelse(!is.na(w1$party2[i]),ifelse(w1$party2[i]==1,-3,w1$pid7[i]),w1$pid7[i]) # strong D
	w1$pid7[i] <- ifelse(!is.na(w1$party2[i]),ifelse(w1$party2[i]==2,-2,w1$pid7[i]),w1$pid7[i]) # weak D
	w1$pid7[i] <- ifelse(!is.na(w1$party3[i]),ifelse(w1$party3[i]==1,3,w1$pid7[i]),w1$pid7[i]) # strong R
	w1$pid7[i] <- ifelse(!is.na(w1$party3[i]),ifelse(w1$party3[i]==2,2,w1$pid7[i]),w1$pid7[i]) # weak R
}
table(w1$pid7)/sum(table(w1$pid7)) 

w1$ideo <- NULL
for(i in 1:nrow(w1)){
  w1$ideo[i] <- NA
  w1$ideo[i] <- ifelse(w1$ideo4[i]==3,0,NA)
  w1$ideo[i] <- ifelse(w1$ideo1[i]==1,-1,w1$ideo[i])
  w1$ideo[i] <- ifelse(w1$ideo1[i]==2,1,w1$ideo[i])
  w1$ideo[i] <- ifelse(!is.na(w1$ideo4[i]),ifelse(w1$ideo4[i]==1,-1,w1$ideo[i]),w1$ideo[i])
  w1$ideo[i] <- ifelse(!is.na(w1$ideo4[i]),ifelse(w1$ideo4[i]==2,1,w1$ideo[i]),w1$ideo[i])
}
table(w1$ideo)/sum(table(w1$ideo)) # slightly more heavily conservative


w1$educ <- as.numeric(w1$educ)
w1$income <- car::recode(w1$income,"15=NA")
w1$marital <- as.numeric(w1$marital)
w1$church <- as.numeric(w1$church)

# Race:
race_expanded <- strsplit(w1$race,split = ",",fixed = T)
w1$race_black <- as.numeric(grepl("1",race_expanded)) # race==black
w1$race_white <- as.numeric(grepl("3",race_expanded)) # race==white
w1$race_white_alone <- as.numeric(w1$race=="3") # race==white alone

# Polinfo:
w1$polinfo1 <- as.numeric(w1$Q152==3)
w1$polinfo2 <- as.numeric(w1$Q154==1)
w1$polinfo3 <- as.numeric(w1$Q156==1)
w1$polinfo4 <- as.numeric(w1$Q158==1)
w1$polinfo5 <- as.numeric(w1$Q160==3)
w1$polinfo <- apply(w1[,c("polinfo1","polinfo2","polinfo3","polinfo4","polinfo5")],1,sum)
table(w1$polinfo)/sum(table(w1$polinfo))

w1$mar_index <- apply(w1[,c("mar_tradeoff",
                            "mar_econ",
                            "mar_costmore",
                            "mar_fewserious",
                            "mar_wrong",
                            "mar_violence",
                            "mar_legmed",
                            "mar_serious",
                            "mar_legrec",
                            "danger_mar"
                            )],1,mean,na.rm=T)

write_csv(w1,"MediaSSI_Dec2017_recoded.csv")
