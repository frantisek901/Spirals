## Replication File for:
## ``Persuading the Enemy: Estimating the Persuasive Effects of Partisan Media with the Preference-Incorporating Choice and Assignment Design"
## Justin de Benedictis-Kessner, Matthew A. Baum, Adam J. Berinsky, and Teppei Yamamoto

## ---------- ##
#### Notes: ####
## ---------- ##

# This is the second script file needed to reproduce the results from the paper
# Run the first script, ``01-survey_recodes.R" first to produce recoded survey dataset that this script needs
# That script also has all packages and functions needed for the remainder of these scripts

## --------------------- ##
#### Preliminary stuff ####
## --------------------- ##

library(descr)
library(xtable)
library(tidyverse)
library(car)
library(lpSolve)
library(ggplot2)
library(stargazer)
library(Cairo)
library(nnet)

## --------- ##
#### style ####
## --------- ##
'%.%' <- function(x,y) paste(x,y,sep='')

CairoFonts(regular="CMU Serif",
					 bold="CMU Serif Extra"
)

red_mit = '#A31F34'
red_light = '#A9606C'
blue_mit = '#315485'
grey_light= '#C2C0BF'
grey_dark = '#8A8B8C'
black = '#353132'


## ------------------------- ##
#### Read in recoded data: ####
## ------------------------- ##

w1 <- read_csv("MediaSSI_Dec2017_recoded.csv")


## ----------------------- ##
#### Free Choice Tables: ####
## ----------------------- ##

# Check match between stated and actual prefs
discrepancy_table <- print(crosstab(w1$med_choice,w1$med_pref,prop.r=F,prop.t=T,prop.c=F,prop.chisq=F)) # equal across choices, a little more consistency for entertainment
discrepancy_table <- descr:::CreateNewTab(discrepancy_table)

## Output Table A-4:
write_csv(as_tibble(discrepancy_table),"discrepancy_table.csv")

## Assessing selective exposure:
# predictors of media preferences: Multinomial Logit:
w1$med_pref <- relevel(factor(w1$med_pref),ref = "Entertainment")
descfit1b <- (multinom(med_pref ~ (pid==1) + # Rep
                       (pid==-1) +  # Dem
                       (ideo==1) + # conservative
                       (ideo==-1) + # liberal
                       (gender==1) + # male
                       race_white_alone + # white
                       polinfo + # political knowledge, 0-1 scale
                       (educ>3) + # 2-yr college degree or more
                       (income>7), # $50k or more
                       data=w1))
summary(descfit1b)
stargazer(descfit1b,
					type="text",
					out = "descriptive_mnl.txt",
          dep.var.labels = c("Prefer Fox over Entertainment", "Prefer MSNBC over Entertainment"),
          #df = F,omit.stat = c("rsq","ser"),
          covariate.labels = c("Republican","Democrat","Conservative","Liberal","Male","White","Political Knowledge","Education: college degree or more","Income: $50k or more")
)

# Predicted probabilities:
w1$rep <- as.numeric(w1$pid==1)
w1$dem <- as.numeric(w1$pid==-1)
w1$conservative <- as.numeric(w1$ideo==1)
w1$liberal <- as.numeric(w1$ideo==-1)
w1$male <- as.numeric(w1$gender==1)
w1$race_white <- as.numeric(w1$race_white==1)
w1$high_info <- as.numeric(w1$polinfo>2)
w1$high_ed <- as.numeric(w1$educ>3)
w1$high_inc <- as.numeric(w1$income>7)

descfit1c <- (multinom(med_pref ~ rep # Rep
                       + dem # Dem
                       + conservative # conservative
                       + liberal # liberal
                       + male # male
                       + race_white_alone # white
                       + high_info # political knowledge, 0-1 scale
                       + high_ed # 2-yr college degree or more
                       + high_inc # $50k or more
                       ,data=w1))
summary(descfit1c)

D.rep <- model.frame(descfit1c)
D.rep$rep <- 1
D.rep$dem <- 0
pred.rep <- predict(descfit1c, newdata = D.rep, type = "probs")
rep.probs <- apply(pred.rep,2,mean) # mean probabilities for each media preference
D.dem <- model.frame(descfit1c)
D.dem$dem <- 1
D.dem$rep <- 0
pred.dem <- predict(descfit1c, newdata = D.dem, type = "probs")
dem.probs <- apply(pred.dem,2,mean) # mean probabilities for each media preference
D.cons <- model.frame(descfit1c)
D.cons$conservative <- 1
D.cons$liberal <- 0
pred.cons <- predict(descfit1c, newdata = D.cons, type = "probs")
cons.probs <- apply(pred.cons,2,mean) # mean probabilities for each media preference
D.lib <- model.frame(descfit1c)
D.lib$conservative <- 0
D.lib$liberal <- 1
pred.lib <- predict(descfit1c, newdata = D.lib, type = "probs")
lib.probs <- apply(pred.lib,2,mean) # mean probabilities for each media preference
D.male <- model.frame(descfit1c)
D.male$male <- 1
pred.male <- predict(descfit1c, newdata = D.male, type = "probs")
male.probs <- apply(pred.male,2,mean) # mean probabilities for each media preference
D.female <- model.frame(descfit1c)
D.female$male <- 0
pred.female <- predict(descfit1c, newdata = D.female, type = "probs")
female.probs <- apply(pred.female,2,mean) # mean probabilities for each media preference
D.white <- model.frame(descfit1c)
D.white$race_white_alone <- 1
pred.white <- predict(descfit1c, newdata = D.white, type = "probs")
white.probs <- apply(pred.white,2,mean) # mean probabilities for each media preference
D.nonwhite <- model.frame(descfit1c)
D.nonwhite$race_white_alone <- 0
pred.nonwhite <- predict(descfit1c, newdata = D.nonwhite, type = "probs")
nonwhite.probs <- apply(pred.nonwhite,2,mean) # mean probabilities for each media preference
D.high_info <- model.frame(descfit1c)
D.high_info$high_info <- 1
pred.high_info <- predict(descfit1c, newdata = D.high_info, type = "probs")
high_info.probs <- apply(pred.high_info,2,mean)
D.low_info <- model.frame(descfit1c)
D.low_info$high_info <- 0
pred.low_info <- predict(descfit1c, newdata = D.low_info, type = "probs")
low_info.probs <- apply(pred.low_info,2,mean)
D.high_ed <- model.frame(descfit1c)
D.high_ed$high_ed <- 1
pred.high_ed <- predict(descfit1c, newdata = D.high_ed, type = "probs")
high_ed.probs <- apply(pred.high_ed,2,mean)
D.low_ed <- model.frame(descfit1c)
D.low_ed$high_ed <- 0
pred.low_ed <- predict(descfit1c, newdata = D.low_ed, type = "probs")
low_ed.probs <- apply(pred.low_ed,2,mean)
D.high_inc <- model.frame(descfit1c)
D.high_inc$high_inc <- 1
pred.high_inc <- predict(descfit1c, newdata = D.high_inc, type = "probs")
high_inc.probs <- apply(pred.high_inc,2,mean)
D.low_inc <- model.frame(descfit1c)
D.low_inc$high_inc <- 0
pred.low_inc <- predict(descfit1c, newdata = D.low_inc, type = "probs")
low_inc.probs <- apply(pred.low_inc,2,mean)

## Table A-1: Demographic predictors of Media Choice, Predicted Probabilities ##
write_csv(data.frame(cbind(c("Republican","Democrat","Conservative","Liberal","Male","Female","White alone","Non-white","High Political Knowledge","Low Political Knowledge","Education: college degree or more","Education: less than college degree","Income: $50k or more","Income: less than $50k"),rbind(rep.probs,dem.probs,cons.probs,lib.probs,male.probs,female.probs,white.probs,nonwhite.probs,high_info.probs,low_info.probs,high_ed.probs,low_ed.probs,high_inc.probs,low_inc.probs))),
          path = "table_MNL_pred_probs.csv")

## Table A-2: Demographic predictors of Media Choice, MNL coefficients
stargazer(descfit1c,
					type="text",
					out = "descriptive_mnl.txt",
					dep.var.labels = c("Prefer Fox over Entertainment", "Prefer MSNBC over Entertainment"),
					#df = F,omit.stat = c("rsq","ser"),
					covariate.labels = c("Republican","Democrat","Conservative","Liberal","Male","White","Political Knowledge","Education: college degree or more","Income: $50k or more")
)

## Adding more variables to look at 7-point PID and media trust:
descfit1_v2 <- (multinom(med_pref ~ 
												 	relevel(factor(pid7),ref="0") + 
											 	(ideo==1) + # conservative
											 	(ideo==-1) + # liberal
											 	(gender==1) + # male
											 	race_white_alone + # white
											 	polinfo + # political knowledge, 0-1 scale
											 	(educ>3) + # 2-yr college degree or more
											 	(income>7) + # $50k or more
												 hmedia,
											 data=w1))
summary(descfit1_v2)

# Output Table A-3: Demographic predictors of Media Choice, v2 ##
stargazer(descfit1_v2,
					type="text",
					out = "descriptive_mnl_v2.txt",
					# dep.var.labels = c("Prefer Fox over Entertainment", "Prefer MSNBC over Entertainment"),
					#df = F,omit.stat = c("rsq","ser"),
					covariate.labels = c("Strong Democrat","Weak Democrat","Lean Democrat","Lean Republican","Weak Republican","Strong Republican","Conservative","Liberal","Male","White","Political Knowledge","Education: college degree or more","Income: $50k or more","Hostile Media Index")
)

descfit_discrepancy <- (lm((med_pref != med_choice) ~ 
													 	dem + 
													 	rep + 
													 	(ideo==1) + # conservative
													 	(ideo==-1) + # liberal
													 	(gender==1) + # male
													 	race_white_alone + # white
													 	polinfo + # political knowledge, 0-1 scale
													 	(educ>3) + # 2-yr college degree or more
													 	(income>7) + # $50k or more
													 	hmedia,
													 data=subset(w1,forcedchoice==0)))
summary(descfit_discrepancy)
stargazer(descfit_discrepancy,
					type="text",
					out = "discrepancy_predictors.txt",
					# dep.var.labels = c("Prefer Fox over Entertainment", "Prefer MSNBC over Entertainment"),
					df = F,omit.stat = c("rsq","ser"),
					covariate.labels = c("Democrat","Republican","Conservative","Liberal","Male","White","Political Knowledge","Education: college degree or more","Income: $50k or more","Hostile Media Index")
)

descfit_discrepancy_ent <- (lm((med_pref != med_choice) ~ 
													 	relevel(factor(pid),ref="0") + 
													 	(ideo==1) + # conservative
													 	(ideo==-1) + # liberal
													 	(gender==1) + # male
													 	race_white_alone + # white
													 	polinfo + # political knowledge, 0-1 scale
													 	(educ>3) + # 2-yr college degree or more
													 	(income>7) + # $50k or more
													 	hmedia,
													 data=subset(w1,forcedchoice==0 & med_pref=="Entertainment")))
summary(descfit_discrepancy_ent)
descfit_discrepancy_fox <- (lm((med_pref != med_choice) ~ 
															 	relevel(factor(pid),ref="0") + 
															 	(ideo==1) + # conservative
															 	(ideo==-1) + # liberal
															 	(gender==1) + # male
															 	race_white_alone + # white
															 	polinfo + # political knowledge, 0-1 scale
															 	(educ>3) + # 2-yr college degree or more
															 	(income>7) + # $50k or more
															 	hmedia,
															 data=subset(w1,forcedchoice==0 & med_pref=="Fox")))
summary(descfit_discrepancy_fox)
descfit_discrepancy_msnbc <- (lm((med_pref != med_choice) ~ 
															 	relevel(factor(pid),ref="0") + 
															 	(ideo==1) + # conservative
															 	(ideo==-1) + # liberal
															 	(gender==1) + # male
															 	race_white_alone + # white
															 	polinfo + # political knowledge, 0-1 scale
															 	(educ>3) + # 2-yr college degree or more
															 	(income>7) + # $50k or more
															 	hmedia,
															 data=subset(w1,forcedchoice==0 & med_pref=="MSNBC")))
summary(descfit_discrepancy_msnbc)

## Output Table A-5: Preditors of Discrepancy Between Preference/Choice ##
stargazer(descfit_discrepancy,descfit_discrepancy_ent,descfit_discrepancy_fox,descfit_discrepancy_msnbc,
					type="text",
					out = "discrepancy_predictors_subsets.txt",
					dep.var.caption = "Dependent Variable: Discrepancy between Preference/Choice",
					column.labels = c("Full Sample", "Prefer Entertainment","Prefer Fox","Prefer MSNBC"),
					dep.var.labels = "",
					df = F,omit.stat = c("rsq","ser"),
					covariate.labels = c("Democrat","Republican","Conservative","Liberal","Male","White","Political Knowledge","Education: college degree or more","Income: $50k or more","Hostile Media Index")
)



outcomes = c(
	"mar_index",
	"actions_index",
	"mar_tradeoff",
	"mar_econ",
	"mar_costmore",
	"mar_fewserious",
	"mar_wrong",
	'mar_violence',
	'mar_legmed',
	'mar_serious',
	'mar_legrec',
	"danger_mar"
)
outcome_labels = c(
	mar_index = "Attitudinal index",
	actions_index = "Sharing index",
	mar_tradeoff = "Addiction/crime tradeoff",
	mar_econ = "Legalization would make econ worse",
	mar_costmore = "Regulation worth cost", 
	mar_fewserious = "Legalization leads to fewer serious crimes", 
	mar_wrong = "Marijuana morally wrong",
	mar_violence = "Marijuana use increases violent crime",
	mar_legmed = "Should be legal for medical use",
	mar_serious = "Marijuana is serious problem",
	mar_legrec = "Should be legal for recreational use",
	danger_mar = "Marijuana is dangerous"
)

# calculate means for all variables by selected media choice:
free.all <- w1 %>%
	filter(!is.na(med_choice) & med_choice==med_pref) %>%
	group_by(med_choice) %>%
	summarize(mar_index = mean(mar_index,na.rm=T),
						actions_index=mean(actions_index,na.rm=T),
						
						mar_tradeoff=mean(mar_tradeoff,na.rm=T),
						mar_econ=mean(mar_econ,na.rm=T),
						mar_costmore=mean(mar_costmore,na.rm=T),
						mar_fewserious=mean(mar_fewserious,na.rm=T),
						mar_wrong=mean(mar_wrong,na.rm=T),
						mar_violence=mean(mar_violence,na.rm=T),
						mar_legmed=mean(mar_legmed,na.rm=T),
						mar_serious=mean(mar_serious,na.rm=T),
						mar_legrec=mean(mar_legrec,na.rm=T),
						danger_mar=mean(danger_mar,na.rm=T)
	)

free.all <- free.all %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value = "mean"
	)

# tabulate standard deviations for all variables:
free.all.sds <- w1 %>%
	filter(!is.na(med_choice) & med_choice==med_pref) %>%
	group_by(med_choice) %>%
	summarize(mar_index = sd(mar_index,na.rm=T),
						actions_index=sd(actions_index,na.rm=T),
						
						mar_tradeoff=sd(mar_tradeoff,na.rm=T),
						mar_econ=sd(mar_econ,na.rm=T),
						mar_costmore=sd(mar_costmore,na.rm=T),
						mar_fewserious=sd(mar_fewserious,na.rm=T),
						mar_wrong=sd(mar_wrong,na.rm=T),
						mar_violence=sd(mar_violence,na.rm=T),
						mar_legmed=sd(mar_legmed,na.rm=T),
						mar_serious=sd(mar_serious,na.rm=T),
						mar_legrec=sd(mar_legrec,na.rm=T),
						danger_mar=sd(danger_mar,na.rm=T)
	)
free.all.sds <- free.all.sds %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value = "sd"
	)

# join means and SDs into table together, reformat for output
free.all.both <- left_join(free.all,free.all.sds,by = c("med_choice","outcome"))
free.all.both <- free.all.both %>%
	mutate(mean = as.character(round(mean,3)),
		sd = paste0("(",round(sd,3),")"))

free.all.both <- free.all.both %>%
	gather("mean","sd",key = "stat",value="value") %>%
	spread(med_choice,value) %>%
	arrange(factor(outcome, levels=outcomes))

free.all.tab <- free.all.both %>%
	mutate(outcome = factor(outcome,levels=outcomes,labels = outcome_labels)) %>%
	mutate(outcome = ifelse(stat=="sd"," ",as.character(outcome))) %>%
	select(-stat)


## Output Table A-6: opinion differences between free choice subgroups ##
write_csv(free.all.tab,"freechoice_with_sds.csv")
# calculate n sizes to add to table:
nrow(w1[which(w1$med_choice=="Entertainment" & w1$med_choice==w1$med_pref),])
nrow(w1[which(w1$med_choice=="Fox" & w1$med_choice==w1$med_pref),])
nrow(w1[which(w1$med_choice=="MSNBC" & w1$med_choice==w1$med_pref),])


choices = c( # establish order for plots
	"Entertainment",
	"Fox",
	"MSNBC"
)

free.all <- rename(free.all,point = mean) %>%
	mutate(outcome = factor(outcome,
													levels = outcomes,
													labels = outcome_labels,
													ordered = TRUE),
				 med_choice = factor(med_choice,
				 										 levels = choices,
				 										 labels = paste0('Prefer\n',choices),
				 										 ordered = TRUE))


## Comparison between free choice and forced choice with matching preference/assignment:
forced_matching <- w1 %>%
	filter(forcedchoice==1 & med_pref == article_forced) %>% # select only forced choice group
	group_by(med_pref) %>%
	summarize(mar_index = mean(mar_index,na.rm=T),
						actions_index=mean(actions_index,na.rm=T),
						
						mar_tradeoff=mean(mar_tradeoff,na.rm=T),
						mar_econ=mean(mar_econ,na.rm=T),
						mar_costmore=mean(mar_costmore,na.rm=T),
						mar_fewserious=mean(mar_fewserious,na.rm=T),
						mar_wrong=mean(mar_wrong,na.rm=T),
						mar_violence=mean(mar_violence,na.rm=T),
						mar_legmed=mean(mar_legmed,na.rm=T),
						mar_serious=mean(mar_serious,na.rm=T),
						mar_legrec=mean(mar_legrec,na.rm=T),
						danger_mar=mean(danger_mar,na.rm=T)
	) %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value = "Forced choice = preference") %>%
	mutate(outcome = factor(outcome,
													levels = outcomes,
													labels = outcome_labels,
													ordered = TRUE),
				 med_pref = factor(med_pref,
				 										levels = choices,
				 										labels = paste0('Prefer\n',choices),
				 										ordered = TRUE)) %>%
	spread(key="med_pref",value = "Forced choice = preference")

free.all <- free.all %>%
	spread(key="med_choice",value = "point")


forced_matching <- forced_matching %>%
	left_join(free.all,by="outcome") %>%
	select(outcome,
				 `Prefer\nEntertainment.y`,`Prefer\nEntertainment.x`,
				 `Prefer\nFox.y`,`Prefer\nFox.x`,
				 `Prefer\nMSNBC.y`,`Prefer\nMSNBC.x`)

## Table A-7: Mean responses compared between free and forced choice equivalent
write_csv(forced_matching,"freechoice_forcedmatching.csv")
# calculate n sizes for table:
nrow(w1[which(w1$med_choice=="Entertainment" & w1$med_pref=="Entertainment"),])
nrow(w1[which(w1$entertainment==1 & w1$med_pref=="Entertainment"),])
nrow(w1[which(w1$med_choice=="Fox" & w1$med_pref=="Fox"),])
nrow(w1[which(w1$entertainment==1 & w1$med_pref=="Fox"),])
nrow(w1[which(w1$med_choice=="MSNBC" & w1$med_pref=="MSNBC"),])
nrow(w1[which(w1$entertainment==1 & w1$med_pref=="MSNBC"),])

## ----------------------- ##
#### Free Choice Figures ####
## ----------------------- ##

# construct 95% CIs for figures:
free.ci.min <- w1 %>%
	filter(!is.na(med_choice) & med_choice==med_pref) %>%
	group_by(med_choice) %>%
	summarize(mar_tradeoff=mean(mar_tradeoff,na.rm=T)+qnorm(0.025)*(sd(mar_tradeoff,na.rm=T)/sqrt(sum(!is.na(mar_tradeoff)))),
						mar_econ=mean(mar_econ,na.rm=T)+qnorm(0.025)*(sd(mar_econ,na.rm=T)/sqrt(sum(!is.na(mar_econ)))),
						mar_costmore=mean(mar_costmore,na.rm=T)+qnorm(0.025)*(sd(mar_costmore,na.rm=T)/sqrt(sum(!is.na(mar_costmore)))),
						mar_fewserious=mean(mar_fewserious,na.rm=T)+qnorm(0.025)*(sd(mar_fewserious,na.rm=T)/sqrt(sum(!is.na(mar_fewserious)))),
						mar_wrong=mean(mar_wrong,na.rm=T)+qnorm(0.025)*(sd(mar_wrong,na.rm=T)/sqrt(sum(!is.na(mar_wrong)))),
						mar_violence=mean(mar_violence,na.rm=T)+qnorm(0.025)*(sd(mar_violence,na.rm=T)/sqrt(sum(!is.na(mar_violence)))),
						mar_legmed=mean(mar_legmed,na.rm=T)+qnorm(0.025)*(sd(mar_legmed,na.rm=T)/sqrt(sum(!is.na(mar_legmed)))),
						mar_serious=mean(mar_serious,na.rm=T)+qnorm(0.025)*(sd(mar_serious,na.rm=T)/sqrt(sum(!is.na(mar_serious)))),
						mar_legrec=mean(mar_legrec,na.rm=T)+qnorm(0.025)*(sd(mar_legrec,na.rm=T)/sqrt(sum(!is.na(mar_legrec)))),
						danger_mar=mean(danger_mar,na.rm=T)+qnorm(0.025)*(sd(danger_mar,na.rm=T)/sqrt(sum(!is.na(danger_mar)))),
						actions_index=mean(actions_index,na.rm=T)+qnorm(0.025)*(sd(actions_index,na.rm=T)/sqrt(sum(!is.na(actions_index)))),
						mar_index=mean(mar_index,na.rm=T)+qnorm(0.025)*(sd(mar_index,na.rm=T)/sqrt(sum(!is.na(mar_index))))
	)

free.ci.min <- free.ci.min %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value="min")

free.ci.max <- w1 %>%
	filter(!is.na(med_choice) & med_choice==med_pref) %>%
	group_by(med_choice) %>%
	summarize(mar_tradeoff=mean(mar_tradeoff,na.rm=T)+qnorm(0.975)*(sd(mar_tradeoff,na.rm=T)/sqrt(sum(!is.na(mar_tradeoff)))),
						mar_econ=mean(mar_econ,na.rm=T)+qnorm(0.975)*(sd(mar_econ,na.rm=T)/sqrt(sum(!is.na(mar_econ)))),
						mar_costmore=mean(mar_costmore,na.rm=T)+qnorm(0.975)*(sd(mar_costmore,na.rm=T)/sqrt(sum(!is.na(mar_costmore)))),
						mar_fewserious=mean(mar_fewserious,na.rm=T)+qnorm(0.975)*(sd(mar_fewserious,na.rm=T)/sqrt(sum(!is.na(mar_fewserious)))),
						mar_wrong=mean(mar_wrong,na.rm=T)+qnorm(0.975)*(sd(mar_wrong,na.rm=T)/sqrt(sum(!is.na(mar_wrong)))),
						mar_violence=mean(mar_violence,na.rm=T)+qnorm(0.975)*(sd(mar_violence,na.rm=T)/sqrt(sum(!is.na(mar_violence)))),
						mar_legmed=mean(mar_legmed,na.rm=T)+qnorm(0.975)*(sd(mar_legmed,na.rm=T)/sqrt(sum(!is.na(mar_legmed)))),
						mar_serious=mean(mar_serious,na.rm=T)+qnorm(0.975)*(sd(mar_serious,na.rm=T)/sqrt(sum(!is.na(mar_serious)))),
						mar_legrec=mean(mar_legrec,na.rm=T)+qnorm(0.975)*(sd(mar_legrec,na.rm=T)/sqrt(sum(!is.na(mar_legrec)))),
						danger_mar=mean(danger_mar,na.rm=T)+qnorm(0.975)*(sd(danger_mar,na.rm=T)/sqrt(sum(!is.na(danger_mar)))),
						actions_index=mean(actions_index,na.rm=T)+qnorm(0.975)*(sd(actions_index,na.rm=T)/sqrt(sum(!is.na(actions_index)))),
						mar_index=mean(mar_index,na.rm=T)+qnorm(0.975)*(sd(mar_index,na.rm=T)/sqrt(sum(!is.na(mar_index))))
	)

free.ci.max <- free.ci.max %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value="max")

free.ci.all <- left_join(free.ci.min,free.ci.max,by=c("outcome","med_choice")) %>%
	mutate(outcome = factor(outcome,
                               levels = outcomes,
                               labels = outcome_labels,
                               ordered = TRUE),
				 med_choice = factor(med_choice,
                                 levels = choices,
                                 labels = paste0('Prefer\n',choices),
                                 ordered = TRUE)
	)

free.all <- free.all %>%
	gather(`Prefer\nEntertainment`, `Prefer\nFox`, `Prefer\nMSNBC`,
				 key = "med_choice",value="mean")


## Create Figure 2: Average Responses in Free Choice Condition ##
## non-zoomed y-axis:
# plot_free_index <- ggplot(subset(free.all,outcome %in% c("Attitudinal index","Sharing index")), aes(x=med_choice)) +
#       geom_errorbar(aes(ymin=min, ymax=max),
#                     data=subset(free.ci.all,outcome %in% c("Attitudinal index","Sharing index")),
#                     width=.1, size=0.4) +
#       geom_point(aes(y=mean),
#                  data=subset(free.all,outcome %in% c("Attitudinal index","Sharing index")),
#                  size=0.5) +
#       facet_wrap(~ outcome,nrow=1) +
#       #   scale_x_discrete(aes(labels=med_choice)) + 
#       xlab(NULL) +
#       ylab("Mean outcome + 95% CI") +
# 	scale_y_continuous(breaks=seq(0,1,0.25),
# 										 labels=c("(Most\nliberal)\n0\n\n","0.25","0.5","0.75","\n\n1\n(Most\nconservative)"),
# 										 limits = c(0,1),
# 										 sec.axis = dup_axis(name="",
# 										 										breaks=c(0,0.25,0.5,0.75,1),
# 										 										labels = c("(Less\nwillingness\nto share)\n0\n\n\n","0.25","0.5","0.75","\n\n\n1\n(Greater\nwillingness\nto share)"))) +
# 	theme(legend.position='bottom') +
#       theme_bw() + 
#       theme(text=element_text(colour=black,family="CM Roman"))
# 
# fname = "./free_summ_index.pdf"
# if (Sys.info()['sysname'] == 'Windows'){
#       ggsave(fname, plot_free_index, width=12, height=4)
#       embed_fonts(fname, outfile=fname)
# } else {
#       CairoPDF(fname, width=6, height=3.5)
#       print(plot_free_index)
#       dev.off()
# }

## zoomed-in y-axis:
plot_free_index_zoom <- ggplot(subset(free.all,outcome %in% c("Attitudinal index","Sharing index")), aes(x=med_choice)) +
      geom_errorbar(aes(ymin=min, ymax=max),
                    data=subset(free.ci.all,outcome %in% c("Attitudinal index","Sharing index")),
                    width=.1, size=0.4) +
      geom_point(aes(y=mean),
                 data=subset(free.all,outcome %in% c("Attitudinal index","Sharing index")),
                 size=0.5) +
      facet_wrap(~ outcome,nrow=1) +
      #   scale_x_discrete(aes(labels=med_choice)) + 
      xlab(NULL) +
      ylab("Mean outcome + 95% CI") +
	scale_y_continuous(limits=c(0,0.605),
										 breaks=c(0,0.25,0.5),
										 labels=c("\n\n0\n(More\nliberal)","0.25","(More\nconservative)\n\n0.5\n\n\n"),
										 minor_breaks=seq(0,1,0.125),
										 sec.axis = dup_axis(name="",
										 										breaks=c(0,0.25,0.5),
										 										labels=c("\n\n\n0\n(Less\nwillingness\nto share)","0.25","(Greater\nwillingness\nto share)\n\n0.5\n\n\n\n"))) +
      theme(legend.position='bottom') +
      theme_bw() + 
      theme(text=element_text(colour=black,family="CM Roman"))

fname = "./free_summ_index_zoom.pdf"
if (Sys.info()['sysname'] == 'Windows'){
      ggsave(fname, plot_free_index_zoom, width=12, height=4)
      embed_fonts(fname, outfile=fname)
} else {
      CairoPDF(fname, width=6, height=3.5)
      print(plot_free_index_zoom)
      dev.off()
}


## Free choice differences:
(mean(w1$mar_tradeoff[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_tradeoff[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_econ[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_econ[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_costmore[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_costmore[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_fewserious[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_fewserious[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_wrong[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_wrong[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_violence[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_violence[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_legmed[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_legmed[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_serious[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_serious[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$mar_legrec[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_legrec[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 
(mean(w1$danger_mar[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$danger_mar[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 

(mean(w1$mar_index[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_index[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 0.1587464
(mean(w1$actions_index[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$actions_index[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 0.01059103

# in SD terms:
(mean(w1$mar_tradeoff[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_tradeoff[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_tradeoff,na.rm=T) # 
(mean(w1$mar_econ[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_econ[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_econ,na.rm=T) # 
(mean(w1$mar_costmore[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_costmore[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_costmore,na.rm=T) # 
(mean(w1$mar_fewserious[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_fewserious[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_fewserious,na.rm=T) # 
(mean(w1$mar_wrong[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_wrong[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_wrong,na.rm=T) # 
(mean(w1$mar_violence[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_violence[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_violence,na.rm=T) # 
(mean(w1$mar_legmed[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_legmed[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_legmed,na.rm=T) # 
(mean(w1$mar_serious[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_serious[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_serious,na.rm=T) # 
(mean(w1$mar_legrec[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_legrec[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_legrec,na.rm=T) # 
(mean(w1$danger_mar[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$danger_mar[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$danger_mar,na.rm=T) # 

(mean(w1$mar_index[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_index[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$mar_index,na.rm=T) # 0.722
(mean(w1$actions_index[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$actions_index[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T))/sd(w1$actions_index,na.rm=T) # 0.035

##---------------------------##
#### Forced Choice Tables: ####
##---------------------------##

## DVs:
varlist <- c("mar_tradeoff",
             "mar_econ",
             "mar_costmore", 
             "mar_fewserious", 
             "mar_wrong",
             'mar_violence',
             'mar_legmed',
             'mar_serious',
             'mar_legrec',
             "danger_mar",
             "mar_index",
             "actions_index")

## Persuasion effects (only forced choice):
results <- NULL
for(i in varlist){
      dv <- as.data.frame(w1[,i])
      mar_means <- c(tapply(dv,w1$article_forced,mean,na.rm=T))
      mar_se <- c(tapply(dv,w1$article_forced,sd,na.rm=T)/tapply(dv,w1$article_forced,function(x){sqrt(length(na.omit(x)))}))
      mar_hi <- mar_means+mar_se*1.96
      mar_lo <- mar_means-mar_se*1.96
      thisresult <- cbind(c(i,rownames(crosstab(dv,w1$article_forced,prop.c=T)$prop.col)), rbind(colnames(crosstab(dv,w1$article_forced,prop.c=T)$prop.col),crosstab(dv,w1$article_forced,prop.c=T)$prop.col))
      results <- rbind(results,thisresult,cbind("","","",""))
      pdf(paste("",i,"_means.pdf",sep=""))
      plot("",xlim=c(mean(dv,na.rm=T)-1*sd(dv,na.rm=T),mean(dv,na.rm=T)+1*sd(dv,na.rm=T)),ylim=c(0,4),ylab="Article Read",xlab="Mean Outcome",main=paste(i," by treatment w/ 95% CI",sep=""),yaxt="n")
      segments(x0=mar_lo,x1=mar_hi,y0=length(mar_means):1,y1=length(mar_means):1)
      points(mar_means,length(mar_means):1,pch=19)
      axis(2,at=length(mar_means):1,labels=c("Entertainment","Fox","MSNBC"),las=2)
      dev.off()
}
write_csv(results,"results_crosstabs_forced.csv")

results <- NULL
for(i in varlist){
      dv <- w1[,i]
      mar_means <- c(tapply(dv,w1$article_forced,mean,na.rm=T))
      mar_se <- c(tapply(dv,w1$article_forced,sd,na.rm=T)/tapply(dv,w1$article_forced,function(x){sqrt(length(na.omit(x)))}))
      mar_hi <- mar_means+mar_se*1.96
      mar_lo <- mar_means-mar_se*1.96
      thisresult <- cbind(c(i,""), rbind(names(mar_means),mar_means))
      results <- rbind(results,thisresult,cbind("","","",""))
}
write_csv(results,"results_means_forced.csv")


results <- NULL
for(i in varlist){
      dv <- w1[,i]
      fit1 <- lm(dv ~ article_forced,data=w1)
            ht1 <- linearHypothesis(fit1,"article_forcedFox=article_forcedMSNBC")[2,6]

      dv <- w1[w1$pid==1,i]
      fit1rep <- lm(dv ~ article_forced,data=w1[w1$pid==1,])
            ht1rep <- linearHypothesis(fit1rep,"article_forcedFox=article_forcedMSNBC")[2,6]
      
      dv <- w1[w1$pid==-1,i]
      fit1dem <- lm(dv ~ article_forced,data=w1[w1$pid==-1,])
            ht1dem <- linearHypothesis(fit1dem,"article_forcedFox=article_forcedMSNBC")[2,6]
      
      thisresult <- cbind(c(i,rep("",times=(nrow(summary(fit1)$coefficients)-1))),
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          summary(fit1)$coefficients,
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          summary(fit1dem)$coefficients,
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          summary(fit1rep)$coefficients)
      results <- rbind(results,thisresult,cbind("","",paste0("HT p-val= ",round(ht1,4)),"","","","","",paste0("HT p-val= ",round(ht1dem,4)),"","","","","",paste0("HT p-val= ",round(ht1rep,4)),"","",""),cbind("","","","","","","","","","","","","","","","","",""))
      colnames(results) <- c("DV","","Estimate","SE","t","p-value","","","Estimate","SE","t","p-value","","","Estimate","SE","t","p-value")
}
results
write_csv(results,"regression_results_pid.csv")


results <- NULL
for(i in varlist){
      dv <- w1[w1$med_pref=="Entertainment",i]
      fit1 <- lm(dv ~ article_forced,data=w1[w1$med_pref=="Entertainment",])
            ht1 <- linearHypothesis(fit1,"article_forcedFox=article_forcedMSNBC")[2,6]
      
      dv <- w1[w1$med_pref=="Fox",i]
      fit1rep <- lm(dv ~ article_forced,data=w1[w1$med_pref=="Fox",])
            ht1rep <- linearHypothesis(fit1rep,"article_forcedFox=article_forcedMSNBC")[2,6]
      
      dv <- w1[w1$med_pref=="MSNBC",i]
      fit1dem <- lm(dv ~ article_forced,data=w1[w1$med_pref=="MSNBC",])
            ht1dem <- linearHypothesis(fit1dem,"article_forcedFox=article_forcedMSNBC")[2,6]
      
      thisresult <- cbind(c(i,rep("",times=(nrow(summary(fit1)$coefficients)-1))),
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))), 
                          summary(fit1)$coefficients, 
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          summary(fit1dem)$coefficients,
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          c(rep("",times=(nrow(summary(fit1)$coefficients)))),
                          summary(fit1rep)$coefficients)
      results <- rbind(results,thisresult,cbind("","",paste0("HT p-val= ",round(ht1,4)),"","","","","",paste0("HT p-val= ",round(ht1dem,4)),"","","","","",paste0("HT p-val= ",round(ht1rep,4)),"","",""),cbind("","","","","","","","","","","","","","","","","",""))
      colnames(results) <- c("DV","","Estimate","SE","t","p-value","","","Estimate","SE","t","p-value","","","Estimate","SE","t","p-value")
}
results
write_csv(results,"regression_results_pref.csv")

# in SD terms:
(mean(w1$mar_tradeoff[w1$msnbc==1],na.rm=T)-mean(w1$mar_tradeoff[w1$fox==1],na.rm=T))/sd(w1$mar_tradeoff,na.rm=T)

(mean(w1$mar_tradeoff[w1$msnbc==1 & w1$pid==1],na.rm=T)-mean(w1$mar_tradeoff[w1$fox==1 & w1$pid==1],na.rm=T))/sd(w1$mar_tradeoff,na.rm=T)
(mean(w1$mar_tradeoff[w1$msnbc==1 & w1$pid==-1],na.rm=T)-mean(w1$mar_tradeoff[w1$fox==1 & w1$pid==-1],na.rm=T))/sd(w1$mar_tradeoff,na.rm=T)

#### relating treatment to real-world:
# comparing to gap in free-choice:
(mean(w1$mar_tradeoff[w1$fox==1 & w1$med_pref=="Fox"],na.rm=T)-mean(w1$mar_tradeoff[w1$msnbc==1 & w1$med_pref=="Fox"],na.rm=T))/(mean(w1$mar_tradeoff[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_tradeoff[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 0.093
(mean(w1$mar_econ[w1$fox==1 & w1$med_pref=="Fox"],na.rm=T)-mean(w1$mar_econ[w1$msnbc==1 & w1$med_pref=="Fox"],na.rm=T))/(mean(w1$mar_econ[w1$med_pref=="Fox" & w1$med_choice=="Fox"],na.rm=T)-mean(w1$mar_econ[w1$med_pref=="MSNBC" & w1$med_choice=="MSNBC"],na.rm=T)) # 0.568



## --------------------------- ##
## Forced TE applied to Free ####
## --------------------------- ##

forced.all <- w1 %>%
	filter(forcedchoice==1 & !is.na(med_pref)) %>%
	group_by(med_pref,article_forced) %>%
	summarize(mar_index = mean(mar_index,na.rm=T),
						actions_index=mean(actions_index,na.rm=T),
						
						mar_tradeoff=mean(mar_tradeoff,na.rm=T),
						mar_econ=mean(mar_econ,na.rm=T),
						mar_costmore=mean(mar_costmore,na.rm=T),
						mar_fewserious=mean(mar_fewserious,na.rm=T),
						mar_wrong=mean(mar_wrong,na.rm=T),
						mar_violence=mean(mar_violence,na.rm=T),
						mar_legmed=mean(mar_legmed,na.rm=T),
						mar_serious=mean(mar_serious,na.rm=T),
						mar_legrec=mean(mar_legrec,na.rm=T),
						danger_mar=mean(danger_mar,na.rm=T)
	) %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value = "mean") %>%
	spread(key="article_forced",value = "mean") %>%
	mutate(treat = Fox - MSNBC,
				 treat_FoxEnt = Fox - Entertainment,
				 treat_MSNBCEnt = MSNBC - Entertainment) %>%
	mutate(outcome = factor(outcome,
													levels = outcomes,
													labels = outcome_labels,
													ordered = TRUE))

forced.all$med_pref = factor(forced.all$med_pref,
				 									levels = choices,
				 									labels = paste0('Prefer\n',choices),
				 									ordered = TRUE)



free.se_mean <- w1 %>%
	filter(!is.na(med_choice) & med_choice==med_pref) %>%
	group_by(med_choice) %>%
	summarize(mar_tradeoff=sd(mar_tradeoff,na.rm=T)/sqrt(sum(!is.na(mar_tradeoff))),
						mar_econ=sd(mar_econ,na.rm=T)/sqrt(sum(!is.na(mar_econ))),
						mar_costmore=sd(mar_costmore,na.rm=T)/sqrt(sum(!is.na(mar_costmore))),
						mar_fewserious=sd(mar_fewserious,na.rm=T)/sqrt(sum(!is.na(mar_fewserious))),
						mar_wrong=sd(mar_wrong,na.rm=T)/sqrt(sum(!is.na(mar_wrong))),
						mar_violence=sd(mar_violence,na.rm=T)/sqrt(sum(!is.na(mar_violence))),
						mar_legmed=sd(mar_legmed,na.rm=T)/sqrt(sum(!is.na(mar_legmed))),
						mar_serious=sd(mar_serious,na.rm=T)/sqrt(sum(!is.na(mar_serious))),
						mar_legrec=sd(mar_legrec,na.rm=T)/sqrt(sum(!is.na(mar_legrec))),
						danger_mar=sd(danger_mar,na.rm=T)/sqrt(sum(!is.na(danger_mar))),
						mar_index=sd(mar_index,na.rm=T)/sqrt(sum(!is.na(mar_index))),
						actions_index=sd(actions_index,na.rm=T)/sqrt(sum(!is.na(actions_index)))
	) %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value = "se_free_mean")

force.se <- w1 %>%
	filter(forcedchoice==1 & !is.na(med_pref)) %>%
	group_by(med_pref,article_forced) %>%
	summarize(mar_tradeoff=sd(mar_tradeoff,na.rm=T)/sqrt(sum(!is.na(mar_tradeoff))),
						mar_econ=sd(mar_econ,na.rm=T)/sqrt(sum(!is.na(mar_econ))),
						mar_costmore=sd(mar_costmore,na.rm=T)/sqrt(sum(!is.na(mar_costmore))),
						mar_fewserious=sd(mar_fewserious,na.rm=T)/sqrt(sum(!is.na(mar_fewserious))),
						mar_wrong=sd(mar_wrong,na.rm=T)/sqrt(sum(!is.na(mar_wrong))),
						mar_violence=sd(mar_violence,na.rm=T)/sqrt(sum(!is.na(mar_violence))),
						mar_legmed=sd(mar_legmed,na.rm=T)/sqrt(sum(!is.na(mar_legmed))),
						mar_serious=sd(mar_serious,na.rm=T)/sqrt(sum(!is.na(mar_serious))),
						mar_legrec=sd(mar_legrec,na.rm=T)/sqrt(sum(!is.na(mar_legrec))),
						danger_mar=sd(danger_mar,na.rm=T)/sqrt(sum(!is.na(danger_mar))),
						mar_index=sd(mar_index,na.rm=T)/sqrt(sum(!is.na(mar_index))),
						actions_index=sd(actions_index,na.rm=T)/sqrt(sum(!is.na(actions_index)))
	)

force.se <- force.se %>%
	gather("mar_index",
				 "actions_index",
				 
				 "mar_tradeoff",
				 "mar_econ",
				 "mar_costmore", 
				 "mar_fewserious", 
				 "mar_wrong",
				 'mar_violence',
				 'mar_legmed',
				 'mar_serious',
				 'mar_legrec',
				 "danger_mar",
				 key="outcome",value = "sd") %>%
	spread(key="article_forced",value="sd") %>%
	mutate(se_treat = sqrt(Fox^2+MSNBC^2),
				 se_treat_FoxEnt = sqrt(Fox^2 + Entertainment^2),
				 se_treat_MSNBCEnt = sqrt(MSNBC^2 + Entertainment^2)) %>%
	select(-Fox, -MSNBC, -Entertainment)

free.force.ses <- left_join(free.se_mean,force.se, by=c("med_choice" = "med_pref","outcome" = "outcome"))


free.force.ses$outcome <- factor(free.force.ses$outcome,
                                  levels = outcomes,
                                  labels = paste0(outcome_labels),
                                  ordered = TRUE)
free.force.ses$med_choice <- factor(free.force.ses$med_choice,
                                    levels = choices,
                                    labels = paste0('Prefer\n',choices),
                                    ordered = TRUE)



## combine forced choice treatment and free-choice diffs:
free.force.all <- left_join(free.all,forced.all, by=c("med_choice" = "med_pref","outcome"="outcome"))
free.force.all <- left_join(free.force.all,free.force.ses, by=c("med_choice","outcome"))

free.treated <- free.force.all %>%
	mutate(treat_opp = ifelse(med_choice=="Prefer\nFox",-treat,treat),
				 treat_opp = ifelse(med_choice=="Prefer\nEntertainment",NA,treat_opp),
				 point_treated_opp = mean + treat_opp,
				 point_treated_FoxEnt = mean + treat_FoxEnt,
				 point_treated_MSNBCEnt = mean + treat_MSNBCEnt)

free.treated <- free.treated %>%
	mutate(treated_ci.lo = point_treated_opp + qnorm(0.025)*sqrt(se_free_mean^2 + se_treat^2),
				 treated_ci.hi = point_treated_opp + qnorm(0.975)*sqrt(se_free_mean^2 + se_treat^2),
				 treated_FoxEnt_ci.lo = point_treated_FoxEnt + qnorm(0.025)*sqrt(se_free_mean^2 + se_treat_FoxEnt^2),
				 treated_FoxEnt_ci.hi = point_treated_FoxEnt + qnorm(0.975)*sqrt(se_free_mean^2 + se_treat_FoxEnt^2),
				 treated_MSNBCEnt_ci.lo = point_treated_MSNBCEnt + qnorm(0.025)*sqrt(se_free_mean^2 + se_treat_MSNBCEnt^2),
				 treated_MSNBCEnt_ci.hi = point_treated_MSNBCEnt + qnorm(0.975)*sqrt(se_free_mean^2 + se_treat_MSNBCEnt^2),
				 point_ci.lo = mean + qnorm(0.025)*se_free_mean,
				 point_ci.hi = mean + qnorm(0.975)*se_free_mean
	)



# for plot with Ent seekers:
free.treated.est <- free.treated %>%
	select(med_choice,outcome,mean,point_treated_opp,point_treated_MSNBCEnt,point_treated_FoxEnt) %>%
	gather("mean","point_treated_opp","point_treated_MSNBCEnt","point_treated_FoxEnt",
				 key="variable",value="value") %>%
	mutate(variable = factor(variable,
													 levels=c("mean","point_treated_opp","point_treated_MSNBCEnt","point_treated_FoxEnt"),
													 labels=c("point","treated","treated_MSNBCEnt","treated_FoxEnt")))

free.treated.cis <- free.treated %>%
	select(med_choice,outcome,point_ci.lo,point_ci.hi,treated_ci.lo,treated_ci.hi,treated_FoxEnt_ci.lo,treated_FoxEnt_ci.hi,treated_MSNBCEnt_ci.lo,treated_MSNBCEnt_ci.hi) %>%
	gather("point_ci.lo","point_ci.hi","treated_ci.lo","treated_ci.hi","treated_FoxEnt_ci.lo","treated_FoxEnt_ci.hi","treated_MSNBCEnt_ci.lo","treated_MSNBCEnt_ci.hi",
				 key="variable",value="value") %>%
	mutate(var = gsub(".*\\_(ci\\.\\w+)$","\\1",variable),
				 variable = gsub("(.*)\\_(ci\\.\\w+)$","\\1",variable)) %>%
	spread(key="var",value="value")


free.treated.all <- left_join(free.treated.est,free.treated.cis,by=c("med_choice","outcome","variable"))

# Version with only Fox/MSNBC
free.treated.partisans <- free.treated.all %>%
	filter(med_choice!="Prefer\nEntertainment") %>%
	filter(variable %in% c("point","treated"))

### version not used in paper with all individual DVs: 
# plot_free_treated <- ggplot(free.treated.partisans, aes(x=med_choice)) +
#       geom_errorbar(aes(ymin=ci.lo, ymax=ci.hi,shape=variable),position=position_dodge(width = 0.3),
#                     width=.1, size=0.5) +
#       geom_point(aes(y=value,shape=variable),
#                  position=position_dodge(width = 0.3),size=3) +
#       #   geom_point(aes(y=point_treated),position=position_dodge(width = 0.4), shape=2, size=3,
#       #              data=free.force.all) +
#       facet_wrap(~ outcome,nrow=2) +
#       xlab(NULL) +
#       ylab("Estimate + 95% CI") +
#       scale_y_continuous(limits=c(0,0.605),breaks=seq(0,1,0.25),labels=c("0","0.25","0.5","0.75","1"),minor_breaks=seq(0,1,0.125)) +
#       scale_shape_manual(labels=c("Free Choice","\nTreated w/\nOppositional \nMedia"),values=c(16,2)) +
#       # scale_shape_manual(labels=c("Free Choice","Treated w/ Fox\ninstead of preference","Treated w/ MSNBC\ninstead of preference"),values=c(16,2,22)) +
#       theme_bw() +
#       theme(legend.position=c(0.92,0.25),text=element_text(size=20),legend.key = element_blank(),legend.background = element_rect(size=0.35,linetype="solid",color="black"),legend.title=element_blank(),legend.key.size = unit(3, 'lines')) +
#       theme(text=element_text(colour="black", family="CM Roman"))
# 
# fname = "./free_treated.pdf"
# # ggsave(fname, plot_free_treated, width=14, height=6)
# if (Sys.info()['sysname'] == 'Windows'){
#       ggsave(fname, plot_free_treated, width=14, height=6)
#       embed_fonts(fname, outfile=fname)
# } else {
#       CairoPDF(fname, width=23, height=8)
#       print(plot_free_treated)
#       dev.off()
# }

## Create Figure 4: The Effect of Opposing Media Treatment on Polarization ##
plot_free_treated_index <- ggplot(subset(free.treated.partisans,outcome %in% c("Attitudinal index","Sharing index")), 
																	aes(x=med_choice)) +
      geom_errorbar(aes(ymin=ci.lo, ymax=ci.hi,shape=variable),position=position_dodge(width = 0.3),
                    width=.1, size=0.5) +
      geom_point(aes(y=value,shape=variable),
                 position=position_dodge(width = 0.3),size=3) +
      facet_wrap(~ outcome,nrow=1) +
      xlab(NULL) +
      ylab("Estimate + 95% CI") +
      # scale_y_continuous(limits=c(0,0.605),breaks=seq(0,1,0.25),labels=c("0","0.25","0.5","0.75","1"),minor_breaks=seq(0,1,0.125)) +
	scale_y_continuous(breaks=seq(0,0.5,0.25),minor_breaks=seq(0,1,0.125),
										 labels=c("\n\n0\n(More\nliberal)","0.25","(More\nconservative)\n\n0.5\n\n\n"),
										 limits = c(0,0.605),
										 sec.axis = dup_axis(name="",
										 										breaks=seq(0,0.5,0.25),
										 										labels = c("\n\n\n0\n(Less\nwillingness\nto share)","0.25","(Greater\nwillingness\nto share)\n\n0.5\n\n\n\n"))) +	     
	scale_shape_manual(labels=c("Free Choice","\nTreated w/\nOppositional \nMedia"),values=c(16,2)) +
	theme_bw() +
      theme(legend.position=c(0.87,0.85),legend.key = element_blank(),
      			legend.background = element_rect(size=0.35,linetype="solid",color="black"),
      			legend.title=element_blank(),legend.key.size = unit(3, 'lines'),legend.margin = margin(0,0,0.1,0,unit="cm")) +
      theme(text=element_text(colour="black", family="CM Roman",size=18),
      			axis.title = element_text(size=25),axis.text.x = element_text(size=20),strip.text = element_text(size=20),
      			legend.text = element_text(size=20))

fname = "./free_treated_index.pdf"
if (Sys.info()['sysname'] == 'Windows'){
      ggsave(fname, plot_free_treated_index, width=13, height=8)
      embed_fonts(fname, outfile=fname)
} else {
      CairoPDF(fname, width=13, height=8)
      print(plot_free_treated_index)
      dev.off()
}




# make version for just-Ent plot:
free.treated.Ent <- free.treated.all %>%
	filter(med_choice=="Prefer\nEntertainment") %>%
	filter(variable != "treated")


## Figure 5: The Effect of Media Treatment on Entertainment-Readers ##
# version with all individual DVs:
# plot_free_treated_EntOnly <- ggplot(free.treated.Ent, aes(x=variable)) +
# 	geom_errorbar(aes(ymin=ci.lo, ymax=ci.hi,shape=variable),
# 								width=.1, size=0.5) +
# 	geom_point(aes(y=value,shape=variable),
# 						 size=3) +
# 	facet_wrap(~ outcome,nrow=2) +
# 	xlab(NULL) +
# 	ylab("Estimate + 95% CI") +
# 	scale_y_continuous(limits=c(0,0.605),breaks=seq(0,1,0.25),labels=c("0","0.25","0.5","0.75","1"),minor_breaks=seq(0,1,0.125)) + 
# 	scale_shape_manual(labels=c("Free Choice","Treated w/ Fox","Treated w/ MSNBC"),values=c(16,2,22)) +
# 	theme_bw() +
# 	theme(panel.grid.minor = element_line(colour = "grey98", size = 0.05), 
# 				panel.grid.major = element_line(colour = "grey90", size = 0.25)) +
# 	theme(legend.position=c(0.92,0.25),text=element_text(size=20),legend.key = element_blank(),legend.background = element_rect(size=0.35,linetype="solid",color="black"),legend.title=element_blank(),legend.key.height = unit(1.5, 'lines'), axis.text.x=element_blank()) + 
# 	theme(text=element_text(colour="black", family="CM Roman"))
# 
# fname = "./free_treated_EntOnly.pdf"
# if (Sys.info()['sysname'] == 'Windows'){
# 	ggsave(fname, plot_free_treated_EntOnly_index, width=14, height=6)
# 	embed_fonts(fname, outfile=fname)
# } else {
# 	CairoPDF(fname, width=23, height=8)
# 	print(plot_free_treated_EntOnly)
# 	dev.off()
# }

plot_free_treated_EntOnly_index <- ggplot(subset(free.treated.Ent,outcome %in% c("Attitudinal index","Sharing index")), 
																					aes(x=variable)) +
	geom_errorbar(aes(ymin=ci.lo, ymax=ci.hi,shape=variable),
								width=.1, size=0.5) +
	geom_point(aes(y=value,shape=variable),
						 size=2) +
	#   geom_point(aes(y=point_treated),position=position_dodge(width = 0.4), shape=2, size=3,
	#              data=free.force.all2) +
	facet_wrap(~ outcome,nrow=1) +
	xlab(NULL) +
	ylab("Estimate + 95% CI") +
	# scale_y_continuous(limits=c(0,0.605),breaks=seq(0,1,0.25),labels=c("0","0.25","0.5","0.75","1"),minor_breaks=seq(0,1,0.125)) + 
	scale_y_continuous(breaks=seq(0,0.5,0.25),minor_breaks=seq(0,1,0.125),
										 labels=c("\n\n0\n(More\nliberal)","0.25","(More\nconservative)\n\n0.5\n\n\n"),
										 limits = c(0,0.605),
										 sec.axis = dup_axis(name="",
										 										breaks=seq(0,0.5,0.25),
										 										labels = c("\n\n\n0\n(Less\nwillingness\nto share)","0.25","(Greater\nwillingness\nto share)\n\n0.5\n\n\n\n"))) +	
	scale_x_discrete(labels=c("Free\nChoice","Treated\nw/ Fox","Treated\nw/ MSNBC"),
									 breaks=c("point","treated_FoxEnt","treated_MSNBCEnt")) +
	# scale_shape_manual(labels=c("Free Choice","Treated w/ Fox","Treated w/ MSNBC"),values=c(16,2,22)) +
	theme_bw() +
	theme(legend.position="none",legend.key = element_blank(),
				legend.background = element_rect(size=0.35,linetype="solid",color="black"),
				legend.title=element_blank(),legend.key.height = unit(1.5, 'lines')) + 
	theme(text=element_text(colour="black", family="CM Roman",size=12),
				axis.text.x=element_text(size=8),axis.text.y=element_text(size=7))

fname = "./free_treated_EntOnly_index.pdf"
if (Sys.info()['sysname'] == 'Windows'){
	ggsave(fname, plot_free_treated_EntOnly_index, width=6, height=3.5)
	embed_fonts(fname, outfile=fname)
} else {
	CairoPDF(fname, width=6, height=3.5)
	print(plot_free_treated_EntOnly_index)
	dev.off()
}


## ------------------------ ##
## Forced Choice Analyses ####
## ------------------------ ##

### T-Tests for hostile media index:
t.test(x=w1$hmedia[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$hmedia[w1$fox==1 & w1$med_pref=="Entertainment"]) # insig
t.test(x=w1$hmedia[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$hmedia[w1$fox==1 & w1$med_pref=="Fox"]) # insig
t.test(x=w1$hmedia[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$hmedia[w1$fox==1 & w1$med_pref=="MSNBC"]) # insig


### Regressions for all individual DVs: 
results_reg <- NULL
results_reg.ht <- NULL
for(i in varlist){
	dv <- as.data.frame(w1)[,i]
	thisfit <- lm(dv ~ w1$article_forced)
	results_reg <- rbind(results_reg,summary(thisfit)$coef,c("","","",""))
	ht <- linearHypothesis(thisfit,"w1$article_forcedFox=w1$article_forcedMSNBC")[2,6] # p-value from hypothesis tests
	
	results_reg.ht <- c(results_reg.ht,ht)
}



## Table B-1, B-2, B-3, B-4, B-5, B-6, B-7, and B-8 subgroup t-tests:
# pooled:
marindex_all <- t.test(x=w1$mar_index[w1$msnbc==1],y=w1$mar_index[w1$fox==1])
tradeoff_all <- t.test(x=w1$mar_tradeoff[w1$msnbc==1],y=w1$mar_tradeoff[w1$fox==1])
econ_all <- t.test(x=w1$mar_econ[w1$msnbc==1],y=w1$mar_econ[w1$fox==1])
costmore_all <- t.test(x=w1$mar_costmore[w1$msnbc==1],y=w1$mar_costmore[w1$fox==1]) 
fewserious_all <- t.test(x=w1$mar_fewserious[w1$msnbc==1],y=w1$mar_fewserious[w1$fox==1]) 
wrong_all <- t.test(x=w1$mar_wrong[w1$msnbc==1],y=w1$mar_wrong[w1$fox==1])
violence_all <- t.test(x=w1$mar_violence[w1$msnbc==1],y=w1$mar_violence[w1$fox==1])
legmed_all <- t.test(x=w1$mar_legmed[w1$msnbc==1],y=w1$mar_legmed[w1$fox==1])
serious_all <- t.test(x=w1$mar_serious[w1$msnbc==1],y=w1$mar_serious[w1$fox==1])
legrec_all <- t.test(x=w1$mar_legrec[w1$msnbc==1],y=w1$mar_legrec[w1$fox==1])
danger_all <- t.test(x=w1$danger_mar[w1$msnbc==1],y=w1$danger_mar[w1$fox==1])
action_all <- t.test(x=w1$actions_index[w1$msnbc==1],y=w1$actions_index[w1$fox==1])


# by respondent PID:
marindex_i <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$pid==0],y=w1$mar_index[w1$fox==1 & w1$pid==0])
marindex_r <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$pid==1],y=w1$mar_index[w1$fox==1 & w1$pid==1])
marindex_d <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$pid==-1],y=w1$mar_index[w1$fox==1 & w1$pid==-1])
tradeoff_i <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$pid==0],y=w1$mar_tradeoff[w1$fox==1 & w1$pid==0])
tradeoff_r <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$pid==1],y=w1$mar_tradeoff[w1$fox==1 & w1$pid==1])
tradeoff_d <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$pid==-1],y=w1$mar_tradeoff[w1$fox==1 & w1$pid==-1])
econ_i <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$pid==0],y=w1$mar_econ[w1$fox==1 & w1$pid==0])
econ_r <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$pid==1],y=w1$mar_econ[w1$fox==1 & w1$pid==1]) 
econ_d <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$pid==-1],y=w1$mar_econ[w1$fox==1 & w1$pid==-1])
costmore_i <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$pid==0],y=w1$mar_costmore[w1$fox==1 & w1$pid==0])
costmore_r <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$pid==1],y=w1$mar_costmore[w1$fox==1 & w1$pid==1]) 
costmore_d <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$pid==-1],y=w1$mar_costmore[w1$fox==1 & w1$pid==-1])
fewserious_i <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$pid==0],y=w1$mar_fewserious[w1$fox==1 & w1$pid==0])
fewserious_r <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$pid==1],y=w1$mar_fewserious[w1$fox==1 & w1$pid==1])
fewserious_d <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$pid==-1],y=w1$mar_fewserious[w1$fox==1 & w1$pid==-1]) 
wrong_i <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$pid==0],y=w1$mar_wrong[w1$fox==1 & w1$pid==0])
wrong_r <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$pid==1],y=w1$mar_wrong[w1$fox==1 & w1$pid==1])
wrong_d <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$pid==-1],y=w1$mar_wrong[w1$fox==1 & w1$pid==-1]) 
violence_i <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$pid==0],y=w1$mar_violence[w1$fox==1 & w1$pid==0])
violence_r <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$pid==1],y=w1$mar_violence[w1$fox==1 & w1$pid==1])
violence_d <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$pid==-1],y=w1$mar_violence[w1$fox==1 & w1$pid==-1]) 
legmed_i <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$pid==0],y=w1$mar_legmed[w1$fox==1 & w1$pid==0])
legmed_r <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$pid==1],y=w1$mar_legmed[w1$fox==1 & w1$pid==1])
legmed_d <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$pid==-1],y=w1$mar_legmed[w1$fox==1 & w1$pid==-1]) 
serious_i <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$pid==0],y=w1$mar_serious[w1$fox==1 & w1$pid==0])
serious_r <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$pid==1],y=w1$mar_serious[w1$fox==1 & w1$pid==1])
serious_d <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$pid==-1],y=w1$mar_serious[w1$fox==1 & w1$pid==-1]) 
legrec_i <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$pid==0],y=w1$mar_legrec[w1$fox==1 & w1$pid==0])
legrec_r <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$pid==1],y=w1$mar_legrec[w1$fox==1 & w1$pid==1])
legrec_d <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$pid==-1],y=w1$mar_legrec[w1$fox==1 & w1$pid==-1]) 
danger_i <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$pid==0],y=w1$danger_mar[w1$fox==1 & w1$pid==0])
danger_r <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$pid==1],y=w1$danger_mar[w1$fox==1 & w1$pid==1])
danger_d <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$pid==-1],y=w1$danger_mar[w1$fox==1 & w1$pid==-1]) 
action_i <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$pid==0],y=w1$actions_index[w1$fox==1 & w1$pid==0])
action_r <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$pid==1],y=w1$actions_index[w1$fox==1 & w1$pid==1])
action_d <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$pid==-1],y=w1$actions_index[w1$fox==1 & w1$pid==-1])


# By media preferences:
marindex_e <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_index[w1$fox==1 & w1$med_pref=="Entertainment"])
marindex_f <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_index[w1$fox==1 & w1$med_pref=="Fox"])
marindex_m <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_index[w1$fox==1 & w1$med_pref=="MSNBC"])
action_e <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$actions_index[w1$fox==1 & w1$med_pref=="Entertainment"])
action_f <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$actions_index[w1$fox==1 & w1$med_pref=="Fox"])
action_m <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$actions_index[w1$fox==1 & w1$med_pref=="MSNBC"])

tradeoff_e <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_tradeoff[w1$fox==1 & w1$med_pref=="Entertainment"])
tradeoff_f <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_tradeoff[w1$fox==1 & w1$med_pref=="Fox"])
tradeoff_m <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_tradeoff[w1$fox==1 & w1$med_pref=="MSNBC"])
econ_e <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_econ[w1$fox==1 & w1$med_pref=="Entertainment"])
econ_f <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_econ[w1$fox==1 & w1$med_pref=="Fox"]) 
econ_m <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_econ[w1$fox==1 & w1$med_pref=="MSNBC"])
costmore_e <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_costmore[w1$fox==1 & w1$med_pref=="Entertainment"])
costmore_f <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_costmore[w1$fox==1 & w1$med_pref=="Fox"]) 
costmore_m <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_costmore[w1$fox==1 & w1$med_pref=="MSNBC"])
fewserious_e <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_fewserious[w1$fox==1 & w1$med_pref=="Entertainment"])
fewserious_f <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_fewserious[w1$fox==1 & w1$med_pref=="Fox"])
fewserious_m <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_fewserious[w1$fox==1 & w1$med_pref=="MSNBC"]) 
wrong_e <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_wrong[w1$fox==1 & w1$med_pref=="Entertainment"])
wrong_f <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_wrong[w1$fox==1 & w1$med_pref=="Fox"])
wrong_m <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_wrong[w1$fox==1 & w1$med_pref=="MSNBC"]) 
violence_e <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_violence[w1$fox==1 & w1$med_pref=="Entertainment"])
violence_f <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_violence[w1$fox==1 & w1$med_pref=="Fox"])
violence_m <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_violence[w1$fox==1 & w1$med_pref=="MSNBC"]) 
legmed_e <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_legmed[w1$fox==1 & w1$med_pref=="Entertainment"])
legmed_f <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_legmed[w1$fox==1 & w1$med_pref=="Fox"])
legmed_m <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_legmed[w1$fox==1 & w1$med_pref=="MSNBC"]) 
serious_e <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_serious[w1$fox==1 & w1$med_pref=="Entertainment"])
serious_f <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_serious[w1$fox==1 & w1$med_pref=="Fox"])
serious_m <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_serious[w1$fox==1 & w1$med_pref=="MSNBC"]) 
legrec_e <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$mar_legrec[w1$fox==1 & w1$med_pref=="Entertainment"])
legrec_f <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$mar_legrec[w1$fox==1 & w1$med_pref=="Fox"])
legrec_m <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$mar_legrec[w1$fox==1 & w1$med_pref=="MSNBC"]) 
danger_e <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$danger_mar[w1$fox==1 & w1$med_pref=="Entertainment"])
danger_f <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$danger_mar[w1$fox==1 & w1$med_pref=="Fox"])
danger_m <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$danger_mar[w1$fox==1 & w1$med_pref=="MSNBC"]) 


hmedia_e <- t.test(x=w1$hmedia[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$hmedia[w1$fox==1 & w1$med_pref=="Entertainment"])
hmedia_f <- t.test(x=w1$hmedia[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$hmedia[w1$fox==1 & w1$med_pref=="Fox"])
hmedia_m <- t.test(x=w1$hmedia[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$hmedia[w1$fox==1 & w1$med_pref=="MSNBC"])

## form into tables:
tab1_indices <- rbind(cbind("DV","Mean[MSNBC]","Mean[Fox]","Treatment Effect","p-value of difference"),
              cbind("All Respondents","","","",""),
              cbind("Attitudinal index",marindex_all$estimate[1],marindex_all$estimate[2],(marindex_all$estimate[2]-marindex_all$estimate[1]),marindex_all$p.value),
              cbind("","","",paste0("(",round(-marindex_all$conf.int[2],3),", ",round(-marindex_all$conf.int[1],3),")"),""),
              cbind("Sharing Index",action_all$estimate[1],action_all$estimate[2],(action_all$estimate[2]-action_all$estimate[1]),action_all$p.value),
              cbind("","","",paste0("(",round(-action_all$conf.int[2],3),", ",round(-action_all$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1),]),nrow(w1[which(w1$fox==1),]),"",""),
              cbind("","","","",""),
              
              cbind("Democratic Respondents","","","",""),
              cbind("Attitudinal index",marindex_d$estimate[1],marindex_d$estimate[2],(marindex_d$estimate[2]-marindex_d$estimate[1]),marindex_d$p.value),
              cbind("","","",paste0("(",round(-marindex_d$conf.int[2],3),", ",round(-marindex_d$conf.int[1],3),")"),""),
              cbind("Sharing Index",action_d$estimate[1],action_d$estimate[2],(action_d$estimate[2]-action_d$estimate[1]),action_d$p.value),
              cbind("","","",paste0("(",round(-action_d$conf.int[2],3),", ",round(-action_d$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$pid==-1),]),nrow(w1[which(w1$fox==1 & w1$pid==-1),]),"",""),
              cbind("","","","",""),
              
              cbind("Republican Respondents","","","",""),
              cbind("Attitudinal index",marindex_r$estimate[1],marindex_r$estimate[2],(marindex_r$estimate[2]-marindex_r$estimate[1]),marindex_r$p.value),
              cbind("","","",paste0("(",round(-marindex_r$conf.int[2],3),", ",round(-marindex_r$conf.int[1],3),")"),""),
              cbind("Sharing Index",action_r$estimate[1],action_r$estimate[2],(action_r$estimate[2]-action_r$estimate[1]),action_r$p.value),
              cbind("","","",paste0("(",round(-action_r$conf.int[2],3),", ",round(-action_r$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$pid==1),]),nrow(w1[which(w1$fox==1 & w1$pid==1),]),"",""),
              cbind("","","","",""),
              
              cbind("Entertainment-watchers","","","",""),
              cbind("Attitudinal index",marindex_e$estimate[1],marindex_e$estimate[2],(marindex_e$estimate[2]-marindex_e$estimate[1]),marindex_e$p.value),
              cbind("","","",paste0("(",round(-marindex_e$conf.int[2],3),", ",round(-marindex_e$conf.int[1],3),")"),""),
              cbind("Sharing Index",action_e$estimate[1],action_e$estimate[2],(action_e$estimate[2]-action_e$estimate[1]),action_e$p.value),
              cbind("","","",paste0("(",round(-action_e$conf.int[2],3),", ",round(-action_e$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$med_pref=="Entertainment"),]),nrow(w1[which(w1$fox==1 & w1$med_pref=="Entertainment"),]),"",""),
              cbind("","","","",""),
              
              cbind("MSNBC-watchers","","","",""),
              cbind("Attitudinal index",marindex_m$estimate[1],marindex_m$estimate[2],(marindex_m$estimate[2]-marindex_m$estimate[1]),marindex_m$p.value),
              cbind("","","",paste0("(",round(-marindex_m$conf.int[2],3),", ",round(-marindex_m$conf.int[1],3),")"),""),
              cbind("Sharing Index",action_m$estimate[1],action_m$estimate[2],(action_m$estimate[2]-action_m$estimate[1]),action_m$p.value),
              cbind("","","",paste0("(",round(-action_m$conf.int[2],3),", ",round(-action_m$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$med_pref=="MSNBC"),]),nrow(w1[which(w1$fox==1 & w1$med_pref=="MSNBC"),]),"",""),
              cbind("","","","",""),
              
              cbind("Fox-watchers","","","",""),
              cbind("Attitudinal index",marindex_f$estimate[1],marindex_f$estimate[2],(marindex_f$estimate[2]-marindex_f$estimate[1]),marindex_f$p.value),
              cbind("","","",paste0("(",round(-marindex_f$conf.int[2],3),", ",round(-marindex_f$conf.int[1],3),")"),""),
              
              cbind("Sharing Index",action_f$estimate[1],action_f$estimate[2],(action_f$estimate[2]-action_f$estimate[1]),action_f$p.value),
              cbind("","","",paste0("(",round(-action_f$conf.int[2],3),", ",round(-action_f$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$med_pref=="Fox"),]),nrow(w1[which(w1$fox==1 & w1$med_pref=="Fox"),]),"","")
)

write.table(tab1_indices,file = "table1_indices.csv",sep = ",",row.names=F,col.names=F)



tab1 <- rbind(cbind("DV","Mean[MSNBC]","Mean[Fox]","Treatment Effect","p-value of difference"),
              cbind("All Respondents","","","",""),
              cbind("Addiction/crime tradeoff",tradeoff_all$estimate[1],tradeoff_all$estimate[2],(tradeoff_all$estimate[2]-tradeoff_all$estimate[1]),tradeoff_all$p.value),
              cbind("","","",paste0("(",round(-tradeoff_all$conf.int[2],3),", ",round(-tradeoff_all$conf.int[1],3),")"),""),
              cbind("Legalization would make econ better",econ_all$estimate[1],econ_all$estimate[2],(econ_all$estimate[2]-econ_all$estimate[1]),econ_all$p.value),
              cbind("","","",paste0("(",round(-econ_all$conf.int[2],3),", ",round(-econ_all$conf.int[1],3),")"),""),
              cbind("Regulation not worth it",costmore_all$estimate[1],costmore_all$estimate[2],(costmore_all$estimate[2]-costmore_all$estimate[1]),costmore_all$p.value),
              cbind("","","",paste0("(",round(-costmore_all$conf.int[2],3),", ",round(-costmore_all$conf.int[1],3),")"),""),
              cbind("Legalization would lead to fewer serious crimes",fewserious_all$estimate[1],fewserious_all$estimate[2],(fewserious_all$estimate[2]-fewserious_all$estimate[1]),fewserious_all$p.value),
              cbind("","","",paste0("(",round(-fewserious_all$conf.int[2],3),", ",round(-fewserious_all$conf.int[1],3),")"),""),
              cbind("Marijuana not morally wrong",wrong_all$estimate[1],wrong_all$estimate[2],(wrong_all$estimate[2]-wrong_all$estimate[1]),wrong_all$p.value),
              cbind("","","",paste0("(",round(-wrong_all$conf.int[2],3),", ",round(-wrong_all$conf.int[1],3),")"),""),
              cbind("Marijuana use does not increase violent crime",violence_all$estimate[1],violence_all$estimate[2],(violence_all$estimate[2]-violence_all$estimate[1]),violence_all$p.value),
              cbind("","","",paste0("(",round(-violence_all$conf.int[2],3),", ",round(-violence_all$conf.int[1],3),")"),""),
              cbind("Should be legal for medical use",legmed_all$estimate[1],legmed_all$estimate[2],(legmed_all$estimate[2]-legmed_all$estimate[1]),legmed_all$p.value),
              cbind("","","",paste0("(",round(-legmed_all$conf.int[2],3),", ",round(-legmed_all$conf.int[1],3),")"),""),
              cbind("Not a serious problem",serious_all$estimate[1],serious_all$estimate[2],(serious_all$estimate[2]-serious_all$estimate[1]),serious_all$p.value),
              cbind("","","",paste0("(",round(-serious_all$conf.int[2],3),", ",round(-serious_all$conf.int[1],3),")"),""),
              cbind("Should be legal for recreational use",legrec_all$estimate[1],legrec_all$estimate[2],(legrec_all$estimate[2]-legrec_all$estimate[1]),legrec_all$p.value),
              cbind("","","",paste0("(",round(-legrec_all$conf.int[2],3),", ",round(-legrec_all$conf.int[1],3),")"),""),
              cbind("Marijuana is dangerous",danger_all$estimate[1],danger_all$estimate[2],(danger_all$estimate[2]-danger_all$estimate[1]),danger_all$p.value),
              cbind("","","",paste0("(",round(-danger_all$conf.int[2],3),", ",round(-danger_all$conf.int[1],3),")"),""),
              cbind("Actions Index",action_all$estimate[1],action_all$estimate[2],(action_all$estimate[2]-action_all$estimate[1]),action_all$p.value),
              cbind("","","",paste0("(",round(-action_all$conf.int[2],3),", ",round(-action_all$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1),]),nrow(w1[which(w1$fox==1),]),"",""),
              cbind("","","","",""),
              
              cbind("Democratic Respondents","","","",""),
              cbind("Addiction/crime tradeoff",tradeoff_d$estimate[1],tradeoff_d$estimate[2],(tradeoff_d$estimate[2]-tradeoff_d$estimate[1]),tradeoff_d$p.value),
              cbind("","","",paste0("(",round(-tradeoff_d$conf.int[2],3),", ",round(-tradeoff_d$conf.int[1],3),")"),""),
              cbind("Legalization would make econ better",econ_d$estimate[1],econ_d$estimate[2],(econ_d$estimate[2]-econ_d$estimate[1]),econ_d$p.value),
              cbind("","","",paste0("(",round(-econ_d$conf.int[2],3),", ",round(-econ_d$conf.int[1],3),")"),""),
              cbind("Regulation not worth it",costmore_d$estimate[1],costmore_d$estimate[2],(costmore_d$estimate[2]-costmore_d$estimate[1]),costmore_d$p.value),
              cbind("","","",paste0("(",round(-costmore_d$conf.int[2],3),", ",round(-costmore_d$conf.int[1],3),")"),""),
              cbind("Legalization would lead to fewer serious crimes",fewserious_d$estimate[1],fewserious_d$estimate[2],(fewserious_d$estimate[2]-fewserious_d$estimate[1]),fewserious_d$p.value),
              cbind("","","",paste0("(",round(-fewserious_d$conf.int[2],3),", ",round(-fewserious_d$conf.int[1],3),")"),""),
              cbind("Marijuana not morally wrong",wrong_d$estimate[1],wrong_d$estimate[2],(wrong_d$estimate[2]-wrong_d$estimate[1]),wrong_d$p.value),
              cbind("","","",paste0("(",round(-wrong_d$conf.int[2],3),", ",round(-wrong_d$conf.int[1],3),")"),""),
              cbind("Marijuana use does not increase violent crime",violence_d$estimate[1],violence_d$estimate[2],(violence_d$estimate[2]-violence_d$estimate[1]),violence_d$p.value),
              cbind("","","",paste0("(",round(-violence_d$conf.int[2],3),", ",round(-violence_d$conf.int[1],3),")"),""),
              cbind("Should be legal for medical use",legmed_d$estimate[1],legmed_d$estimate[2],(legmed_d$estimate[2]-legmed_d$estimate[1]),legmed_d$p.value),
              cbind("","","",paste0("(",round(-legmed_d$conf.int[2],3),", ",round(-legmed_d$conf.int[1],3),")"),""),
              cbind("Not a serious problem",serious_d$estimate[1],serious_d$estimate[2],(serious_d$estimate[2]-serious_d$estimate[1]),serious_d$p.value),
              cbind("","","",paste0("(",round(-serious_d$conf.int[2],3),", ",round(-serious_d$conf.int[1],3),")"),""),
              cbind("Should be legal for recreational use",legrec_d$estimate[1],legrec_d$estimate[2],(legrec_d$estimate[2]-legrec_d$estimate[1]),legrec_d$p.value),
              cbind("","","",paste0("(",round(-legrec_d$conf.int[2],3),", ",round(-legrec_d$conf.int[1],3),")"),""),
              cbind("Marijuana is dangerous",danger_d$estimate[1],danger_d$estimate[2],(danger_d$estimate[2]-danger_d$estimate[1]),danger_d$p.value),
              cbind("","","",paste0("(",round(-danger_d$conf.int[2],3),", ",round(-danger_d$conf.int[1],3),")"),""),
              cbind("Actions Index",action_d$estimate[1],action_d$estimate[2],(action_d$estimate[2]-action_d$estimate[1]),action_d$p.value),
              cbind("","","",paste0("(",round(-action_d$conf.int[2],3),", ",round(-action_d$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$pid==-1),]),nrow(w1[which(w1$fox==1 & w1$pid==-1),]),"",""),
              cbind("","","","",""),
              
              cbind("Republican Respondents","","","",""),
              cbind("Addiction/crime tradeoff",tradeoff_r$estimate[1],tradeoff_r$estimate[2],(tradeoff_r$estimate[2]-tradeoff_r$estimate[1]),tradeoff_r$p.value),
              cbind("","","",paste0("(",round(-tradeoff_r$conf.int[2],3),", ",round(-tradeoff_r$conf.int[1],3),")"),""),
              cbind("Legalization would make econ better",econ_r$estimate[1],econ_r$estimate[2],(econ_r$estimate[2]-econ_r$estimate[1]),econ_r$p.value),
              cbind("","","",paste0("(",round(-econ_r$conf.int[2],3),", ",round(-econ_r$conf.int[1],3),")"),""),
              cbind("Regulation not worth it",costmore_r$estimate[1],costmore_r$estimate[2],(costmore_r$estimate[2]-costmore_r$estimate[1]),costmore_r$p.value),
              cbind("","","",paste0("(",round(-costmore_r$conf.int[2],3),", ",round(-costmore_r$conf.int[1],3),")"),""),
              cbind("Legalization would lead to fewer serious crimes",fewserious_r$estimate[1],fewserious_r$estimate[2],(fewserious_r$estimate[2]-fewserious_r$estimate[1]),fewserious_r$p.value),
              cbind("","","",paste0("(",round(-fewserious_r$conf.int[2],3),", ",round(-fewserious_r$conf.int[1],3),")"),""),
              cbind("Marijuana not morally wrong",wrong_r$estimate[1],wrong_r$estimate[2],(wrong_r$estimate[2]-wrong_r$estimate[1]),wrong_r$p.value),
              cbind("","","",paste0("(",round(-wrong_r$conf.int[2],3),", ",round(-wrong_r$conf.int[1],3),")"),""),
              cbind("Marijuana use does not increase violent crime",violence_r$estimate[1],violence_r$estimate[2],(violence_r$estimate[2]-violence_r$estimate[1]),violence_r$p.value),
              cbind("","","",paste0("(",round(-violence_r$conf.int[2],3),", ",round(-violence_r$conf.int[1],3),")"),""),
              cbind("Should be legal for medical use",legmed_r$estimate[1],legmed_r$estimate[2],(legmed_r$estimate[2]-legmed_r$estimate[1]),legmed_r$p.value),
              cbind("","","",paste0("(",round(-legmed_r$conf.int[2],3),", ",round(-legmed_r$conf.int[1],3),")"),""),
              cbind("Not a serious problem",serious_r$estimate[1],serious_r$estimate[2],(serious_r$estimate[2]-serious_r$estimate[1]),serious_r$p.value),
              cbind("","","",paste0("(",round(-serious_r$conf.int[2],3),", ",round(-serious_r$conf.int[1],3),")"),""),
              cbind("Should be legal for recreational use",legrec_r$estimate[1],legrec_r$estimate[2],(legrec_r$estimate[2]-legrec_r$estimate[1]),legrec_r$p.value),
              cbind("","","",paste0("(",round(-legrec_r$conf.int[2],3),", ",round(-legrec_r$conf.int[1],3),")"),""),
              cbind("Marijuana is dangerous",danger_r$estimate[1],danger_r$estimate[2],(danger_r$estimate[2]-danger_r$estimate[1]),danger_r$p.value),
              cbind("","","",paste0("(",round(-danger_r$conf.int[2],3),", ",round(-danger_r$conf.int[1],3),")"),""),
              cbind("Actions Index",action_r$estimate[1],action_r$estimate[2],(action_r$estimate[2]-action_r$estimate[1]),action_r$p.value),
              cbind("","","",paste0("(",round(-action_r$conf.int[2],3),", ",round(-action_r$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$pid==1),]),nrow(w1[which(w1$fox==1 & w1$pid==1),]),"",""),
              cbind("","","","",""),
              
              cbind("Entertainment-watchers","","","",""),
              cbind("Addiction/crime tradeoff",tradeoff_e$estimate[1],tradeoff_e$estimate[2],(tradeoff_e$estimate[2]-tradeoff_e$estimate[1]),tradeoff_e$p.value),
              cbind("","","",paste0("(",round(-tradeoff_e$conf.int[2],3),", ",round(-tradeoff_e$conf.int[1],3),")"),""),
              cbind("Legalization would make econ better",econ_e$estimate[1],econ_e$estimate[2],(econ_e$estimate[2]-econ_e$estimate[1]),econ_e$p.value),
              cbind("","","",paste0("(",round(-econ_e$conf.int[2],3),", ",round(-econ_e$conf.int[1],3),")"),""),
              cbind("Regulation not worth it",costmore_e$estimate[1],costmore_e$estimate[2],(costmore_e$estimate[2]-costmore_e$estimate[1]),costmore_e$p.value),
              cbind("","","",paste0("(",round(-costmore_e$conf.int[2],3),", ",round(-costmore_e$conf.int[1],3),")"),""),
              cbind("Legalization would lead to fewer serious crimes",fewserious_e$estimate[1],fewserious_e$estimate[2],(fewserious_e$estimate[2]-fewserious_e$estimate[1]),fewserious_e$p.value),
              cbind("","","",paste0("(",round(-fewserious_e$conf.int[2],3),", ",round(-fewserious_e$conf.int[1],3),")"),""),
              cbind("Marijuana not morally wrong",wrong_e$estimate[1],wrong_e$estimate[2],(wrong_e$estimate[2]-wrong_e$estimate[1]),wrong_e$p.value),
              cbind("","","",paste0("(",round(-wrong_e$conf.int[2],3),", ",round(-wrong_e$conf.int[1],3),")"),""),
              cbind("Marijuana use does not increase violent crime",violence_e$estimate[1],violence_e$estimate[2],(violence_e$estimate[2]-violence_e$estimate[1]),violence_e$p.value),
              cbind("","","",paste0("(",round(-violence_e$conf.int[2],3),", ",round(-violence_e$conf.int[1],3),")"),""),
              cbind("Should be legal for medical use",legmed_e$estimate[1],legmed_e$estimate[2],(legmed_e$estimate[2]-legmed_e$estimate[1]),legmed_e$p.value),
              cbind("","","",paste0("(",round(-legmed_e$conf.int[2],3),", ",round(-legmed_e$conf.int[1],3),")"),""),
              cbind("Not a serious problem",serious_e$estimate[1],serious_e$estimate[2],(serious_e$estimate[2]-serious_e$estimate[1]),serious_e$p.value),
              cbind("","","",paste0("(",round(-serious_e$conf.int[2],3),", ",round(-serious_e$conf.int[1],3),")"),""),
              cbind("Should be legal for recreational use",legrec_e$estimate[1],legrec_e$estimate[2],(legrec_e$estimate[2]-legrec_e$estimate[1]),legrec_e$p.value),
              cbind("","","",paste0("(",round(-legrec_e$conf.int[2],3),", ",round(-legrec_e$conf.int[1],3),")"),""),
              cbind("Marijuana is dangerous",danger_e$estimate[1],danger_e$estimate[2],(danger_e$estimate[2]-danger_e$estimate[1]),danger_e$p.value),
              cbind("","","",paste0("(",round(-danger_e$conf.int[2],3),", ",round(-danger_e$conf.int[1],3),")"),""),
              cbind("Actions Index",action_e$estimate[1],action_e$estimate[2],(action_e$estimate[2]-action_e$estimate[1]),action_e$p.value),
              cbind("","","",paste0("(",round(-action_e$conf.int[2],3),", ",round(-action_e$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$med_pref=="Entertainment"),]),nrow(w1[which(w1$fox==1 & w1$med_pref=="Entertainment"),]),"",""),
              cbind("","","","",""),
              
              cbind("MSNBC-watchers","","","",""),
              cbind("Addiction/crime tradeoff",tradeoff_m$estimate[1],tradeoff_m$estimate[2],(tradeoff_m$estimate[2]-tradeoff_m$estimate[1]),tradeoff_m$p.value),
              cbind("","","",paste0("(",round(-tradeoff_m$conf.int[2],3),", ",round(-tradeoff_m$conf.int[1],3),")"),""),
              cbind("Legalization would make econ better",econ_m$estimate[1],econ_m$estimate[2],(econ_m$estimate[2]-econ_m$estimate[1]),econ_m$p.value),
              cbind("","","",paste0("(",round(-econ_m$conf.int[2],3),", ",round(-econ_m$conf.int[1],3),")"),""),
              cbind("Regulation not worth it",costmore_m$estimate[1],costmore_m$estimate[2],(costmore_m$estimate[2]-costmore_m$estimate[1]),costmore_m$p.value),
              cbind("","","",paste0("(",round(-costmore_m$conf.int[2],3),", ",round(-costmore_m$conf.int[1],3),")"),""),
              cbind("Legalization would lead to fewer serious crimes",fewserious_m$estimate[1],fewserious_m$estimate[2],(fewserious_m$estimate[2]-fewserious_m$estimate[1]),fewserious_m$p.value),
              cbind("","","",paste0("(",round(-fewserious_m$conf.int[2],3),", ",round(-fewserious_m$conf.int[1],3),")"),""),
              cbind("Marijuana not morally wrong",wrong_m$estimate[1],wrong_m$estimate[2],(wrong_m$estimate[2]-wrong_m$estimate[1]),wrong_m$p.value),
              cbind("","","",paste0("(",round(-wrong_m$conf.int[2],3),", ",round(-wrong_m$conf.int[1],3),")"),""),
              cbind("Marijuana use does not increase violent crime",violence_m$estimate[1],violence_m$estimate[2],(violence_m$estimate[2]-violence_m$estimate[1]),violence_m$p.value),
              cbind("","","",paste0("(",round(-violence_m$conf.int[2],3),", ",round(-violence_m$conf.int[1],3),")"),""),
              cbind("Should be legal for medical use",legmed_m$estimate[1],legmed_m$estimate[2],(legmed_m$estimate[2]-legmed_m$estimate[1]),legmed_m$p.value),
              cbind("","","",paste0("(",round(-legmed_m$conf.int[2],3),", ",round(-legmed_m$conf.int[1],3),")"),""),
              cbind("Not a serious problem",serious_m$estimate[1],serious_m$estimate[2],(serious_m$estimate[2]-serious_m$estimate[1]),serious_m$p.value),
              cbind("","","",paste0("(",round(-serious_m$conf.int[2],3),", ",round(-serious_m$conf.int[1],3),")"),""),
              cbind("Should be legal for recreational use",legrec_m$estimate[1],legrec_m$estimate[2],(legrec_m$estimate[2]-legrec_m$estimate[1]),legrec_m$p.value),
              cbind("","","",paste0("(",round(-legrec_m$conf.int[2],3),", ",round(-legrec_m$conf.int[1],3),")"),""),
              cbind("Marijuana is dangerous",danger_m$estimate[1],danger_m$estimate[2],(danger_m$estimate[2]-danger_m$estimate[1]),danger_m$p.value),
              cbind("","","",paste0("(",round(-danger_m$conf.int[2],3),", ",round(-danger_m$conf.int[1],3),")"),""),
              cbind("Actions Index",action_m$estimate[1],action_m$estimate[2],(action_m$estimate[2]-action_m$estimate[1]),action_m$p.value),
              cbind("","","",paste0("(",round(-action_m$conf.int[2],3),", ",round(-action_m$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$med_pref=="MSNBC"),]),nrow(w1[which(w1$fox==1 & w1$med_pref=="MSNBC"),]),"",""),
              cbind("","","","",""),
              
              cbind("Fox-watchers","","","",""),
              cbind("Addiction/crime tradeoff",tradeoff_f$estimate[1],tradeoff_f$estimate[2],(tradeoff_f$estimate[2]-tradeoff_f$estimate[1]),tradeoff_f$p.value),
              cbind("","","",paste0("(",round(-tradeoff_f$conf.int[2],3),", ",round(-tradeoff_f$conf.int[1],3),")"),""),
              cbind("Legalization would make econ better",econ_f$estimate[1],econ_f$estimate[2],(econ_f$estimate[2]-econ_f$estimate[1]),econ_f$p.value),
              cbind("","","",paste0("(",round(-econ_f$conf.int[2],3),", ",round(-econ_f$conf.int[1],3),")"),""),
              cbind("Regulation not worth it",costmore_f$estimate[1],costmore_f$estimate[2],(costmore_f$estimate[2]-costmore_f$estimate[1]),costmore_f$p.value),
              cbind("","","",paste0("(",round(-costmore_f$conf.int[2],3),", ",round(-costmore_f$conf.int[1],3),")"),""),
              cbind("Legalization would lead to fewer serious crimes",fewserious_f$estimate[1],fewserious_f$estimate[2],(fewserious_f$estimate[2]-fewserious_f$estimate[1]),fewserious_f$p.value),
              cbind("","","",paste0("(",round(-fewserious_f$conf.int[2],3),", ",round(-fewserious_f$conf.int[1],3),")"),""),
              cbind("Marijuana not morally wrong",wrong_f$estimate[1],wrong_f$estimate[2],(wrong_f$estimate[2]-wrong_f$estimate[1]),wrong_f$p.value),
              cbind("","","",paste0("(",round(-wrong_f$conf.int[2],3),", ",round(-wrong_f$conf.int[1],3),")"),""),
              cbind("Marijuana use does not increase violent crime",violence_f$estimate[1],violence_f$estimate[2],(violence_f$estimate[2]-violence_f$estimate[1]),violence_f$p.value),
              cbind("","","",paste0("(",round(-violence_f$conf.int[2],3),", ",round(-violence_f$conf.int[1],3),")"),""),
              cbind("Should be legal for medical use",legmed_f$estimate[1],legmed_f$estimate[2],(legmed_f$estimate[2]-legmed_f$estimate[1]),legmed_f$p.value),
              cbind("","","",paste0("(",round(-legmed_f$conf.int[2],3),", ",round(-legmed_f$conf.int[1],3),")"),""),
              cbind("Not a serious problem",serious_f$estimate[1],serious_f$estimate[2],(serious_f$estimate[2]-serious_f$estimate[1]),serious_f$p.value),
              cbind("","","",paste0("(",round(-serious_f$conf.int[2],3),", ",round(-serious_f$conf.int[1],3),")"),""),
              cbind("Should be legal for recreational use",legrec_f$estimate[1],legrec_f$estimate[2],(legrec_f$estimate[2]-legrec_f$estimate[1]),legrec_f$p.value),
              cbind("","","",paste0("(",round(-legrec_f$conf.int[2],3),", ",round(-legrec_f$conf.int[1],3),")"),""),
              cbind("Marijuana is dangerous",danger_f$estimate[1],danger_f$estimate[2],(danger_f$estimate[2]-danger_f$estimate[1]),danger_f$p.value),
              cbind("","","",paste0("(",round(-danger_f$conf.int[2],3),", ",round(-danger_f$conf.int[1],3),")"),""),
              cbind("Actions Index",action_f$estimate[1],action_f$estimate[2],(action_f$estimate[2]-action_f$estimate[1]),action_f$p.value),
              cbind("","","",paste0("(",round(-action_f$conf.int[2],3),", ",round(-action_f$conf.int[1],3),")"),""),
              cbind("n",nrow(w1[which(w1$msnbc==1 & w1$med_pref=="Fox"),]),nrow(w1[which(w1$fox==1 & w1$med_pref=="Fox"),]),"","")
)

## Output individual DV tables ##
write.table(tab1,file = "table1.csv",sep = ",",row.names=F,col.names=F)

## Ideology instead of PID:
# by respondent ideology:
marindex_i <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$ideo==0],y=w1$mar_index[w1$fox==1 & w1$ideo==0])
marindex_r <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$ideo==1],y=w1$mar_index[w1$fox==1 & w1$ideo==1])
marindex_d <- t.test(x=w1$mar_index[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_index[w1$fox==1 & w1$ideo==-1])
tradeoff_i <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$ideo==0],y=w1$mar_tradeoff[w1$fox==1 & w1$ideo==0])
tradeoff_r <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$ideo==1],y=w1$mar_tradeoff[w1$fox==1 & w1$ideo==1])
tradeoff_d <- t.test(x=w1$mar_tradeoff[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_tradeoff[w1$fox==1 & w1$ideo==-1])
econ_i <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$ideo==0],y=w1$mar_econ[w1$fox==1 & w1$ideo==0])
econ_r <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$ideo==1],y=w1$mar_econ[w1$fox==1 & w1$ideo==1]) 
econ_d <- t.test(x=w1$mar_econ[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_econ[w1$fox==1 & w1$ideo==-1])
costmore_i <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$ideo==0],y=w1$mar_costmore[w1$fox==1 & w1$ideo==0])
costmore_r <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$ideo==1],y=w1$mar_costmore[w1$fox==1 & w1$ideo==1]) 
costmore_d <- t.test(x=w1$mar_costmore[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_costmore[w1$fox==1 & w1$ideo==-1])
fewserious_i <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$ideo==0],y=w1$mar_fewserious[w1$fox==1 & w1$ideo==0])
fewserious_r <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$ideo==1],y=w1$mar_fewserious[w1$fox==1 & w1$ideo==1])
fewserious_d <- t.test(x=w1$mar_fewserious[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_fewserious[w1$fox==1 & w1$ideo==-1]) 
wrong_i <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$ideo==0],y=w1$mar_wrong[w1$fox==1 & w1$ideo==0])
wrong_r <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$ideo==1],y=w1$mar_wrong[w1$fox==1 & w1$ideo==1])
wrong_d <- t.test(x=w1$mar_wrong[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_wrong[w1$fox==1 & w1$ideo==-1]) 
violence_i <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$ideo==0],y=w1$mar_violence[w1$fox==1 & w1$ideo==0])
violence_r <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$ideo==1],y=w1$mar_violence[w1$fox==1 & w1$ideo==1])
violence_d <- t.test(x=w1$mar_violence[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_violence[w1$fox==1 & w1$ideo==-1]) 
legmed_i <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$ideo==0],y=w1$mar_legmed[w1$fox==1 & w1$ideo==0])
legmed_r <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$ideo==1],y=w1$mar_legmed[w1$fox==1 & w1$ideo==1])
legmed_d <- t.test(x=w1$mar_legmed[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_legmed[w1$fox==1 & w1$ideo==-1]) 
serious_i <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$ideo==0],y=w1$mar_serious[w1$fox==1 & w1$ideo==0])
serious_r <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$ideo==1],y=w1$mar_serious[w1$fox==1 & w1$ideo==1])
serious_d <- t.test(x=w1$mar_serious[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_serious[w1$fox==1 & w1$ideo==-1]) 
legrec_i <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$ideo==0],y=w1$mar_legrec[w1$fox==1 & w1$ideo==0])
legrec_r <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$ideo==1],y=w1$mar_legrec[w1$fox==1 & w1$ideo==1])
legrec_d <- t.test(x=w1$mar_legrec[w1$msnbc==1 & w1$ideo==-1],y=w1$mar_legrec[w1$fox==1 & w1$ideo==-1]) 
danger_i <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$ideo==0],y=w1$danger_mar[w1$fox==1 & w1$ideo==0])
danger_r <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$ideo==1],y=w1$danger_mar[w1$fox==1 & w1$ideo==1])
danger_d <- t.test(x=w1$danger_mar[w1$msnbc==1 & w1$ideo==-1],y=w1$danger_mar[w1$fox==1 & w1$ideo==-1]) 
action_i <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$ideo==0],y=w1$actions_index[w1$fox==1 & w1$ideo==0])
action_r <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$ideo==1],y=w1$actions_index[w1$fox==1 & w1$ideo==1])
action_d <- t.test(x=w1$actions_index[w1$msnbc==1 & w1$ideo==-1],y=w1$actions_index[w1$fox==1 & w1$ideo==-1])


tab1_indices_ideo <- rbind(cbind("DV","Mean[MSNBC]","Mean[Fox]","Treatment Effect","p-value of difference"),
                           cbind("Liberal Respondents","","","",""),
                           cbind("Attitudinal index",marindex_d$estimate[1],marindex_d$estimate[2],(marindex_d$estimate[2]-marindex_d$estimate[1]),marindex_d$p.value),
                           cbind("","","",paste0("(",round(-marindex_d$conf.int[2],3),", ",round(-marindex_d$conf.int[1],3),")"),""),
                           cbind("Sharing Index",action_d$estimate[1],action_d$estimate[2],(action_d$estimate[2]-action_d$estimate[1]),action_d$p.value),
                           cbind("","","",paste0("(",round(-action_d$conf.int[2],3),", ",round(-action_d$conf.int[1],3),")"),""),
                           cbind("n",nrow(w1[which(w1$msnbc==1 & w1$pid==-1),]),nrow(w1[which(w1$fox==1 & w1$pid==-1),]),"",""),
                           cbind("","","","",""),
                           
                           cbind("Conservative Respondents","","","",""),
                           cbind("Attitudinal index",marindex_r$estimate[1],marindex_r$estimate[2],(marindex_r$estimate[2]-marindex_r$estimate[1]),marindex_r$p.value),
                           cbind("","","",paste0("(",round(-marindex_r$conf.int[2],3),", ",round(-marindex_r$conf.int[1],3),")"),""),
                           cbind("Sharing Index",action_r$estimate[1],action_r$estimate[2],(action_r$estimate[2]-action_r$estimate[1]),action_r$p.value),
                           cbind("","","",paste0("(",round(-action_r$conf.int[2],3),", ",round(-action_r$conf.int[1],3),")"),""),
                           cbind("n",nrow(w1[which(w1$msnbc==1 & w1$pid==1),]),nrow(w1[which(w1$fox==1 & w1$pid==1),]),"",""),
                           cbind("","","","","")
)
write.table(tab1_indices_ideo,file = "table1_indices_ideo.csv",sep = ",",row.names=F,col.names=F)

# for full set of DVs:
tab_ideo <- rbind(cbind("Liberal Respondents","","","",""),
                  cbind("Addiction/crime tradeoff",tradeoff_d$estimate[1],tradeoff_d$estimate[2],(tradeoff_d$estimate[2]-tradeoff_d$estimate[1]),tradeoff_d$p.value),
                  cbind("Legalization would make econ better",econ_d$estimate[1],econ_d$estimate[2],(econ_d$estimate[2]-econ_d$estimate[1]),econ_d$p.value),
                  cbind("Regulation not worth it",costmore_d$estimate[1],costmore_d$estimate[2],(costmore_d$estimate[2]-costmore_d$estimate[1]),costmore_d$p.value),
                  cbind("Legalization would lead to fewer serious crimes",fewserious_d$estimate[1],fewserious_d$estimate[2],(fewserious_d$estimate[2]-fewserious_d$estimate[1]),fewserious_d$p.value),
                  cbind("Marijuana not morally wrong",wrong_d$estimate[1],wrong_d$estimate[2],(wrong_d$estimate[2]-wrong_d$estimate[1]),wrong_d$p.value),
                  cbind("Marijuana use does not increase violent crime",violence_d$estimate[1],violence_d$estimate[2],(violence_d$estimate[2]-violence_d$estimate[1]),violence_d$p.value),
                  cbind("Should be legal for medical use",legmed_d$estimate[1],legmed_d$estimate[2],(legmed_d$estimate[2]-legmed_d$estimate[1]),legmed_d$p.value),
                  cbind("Not a serious problem",serious_d$estimate[1],serious_d$estimate[2],(serious_d$estimate[2]-serious_d$estimate[1]),serious_d$p.value),
                  cbind("Should be legal for recreational use",legrec_d$estimate[1],legrec_d$estimate[2],(legrec_d$estimate[2]-legrec_d$estimate[1]),legrec_d$p.value),
                  cbind("Marijuana is dangerous",danger_d$estimate[1],danger_d$estimate[2],(danger_d$estimate[2]-danger_d$estimate[1]),danger_d$p.value),
                  cbind("Actions Index",action_d$estimate[1],action_d$estimate[2],(action_d$estimate[2]-action_d$estimate[1]),action_d$p.value),
                  cbind("","","","",""),
                  cbind("Conservative Respondents","","","",""),
                  cbind("Addiction/crime tradeoff",tradeoff_r$estimate[1],tradeoff_r$estimate[2],(tradeoff_r$estimate[2]-tradeoff_r$estimate[1]),tradeoff_r$p.value),
                  cbind("Legalization would make econ better",econ_r$estimate[1],econ_r$estimate[2],(econ_r$estimate[2]-econ_r$estimate[1]),econ_r$p.value),
                  cbind("Regulation not worth it",costmore_r$estimate[1],costmore_r$estimate[2],(costmore_r$estimate[2]-costmore_r$estimate[1]),costmore_r$p.value),
                  cbind("Legalization would lead to fewer serious crimes",fewserious_r$estimate[1],fewserious_r$estimate[2],(fewserious_r$estimate[2]-fewserious_r$estimate[1]),fewserious_r$p.value),
                  cbind("Marijuana not morally wrong",wrong_r$estimate[1],wrong_r$estimate[2],(wrong_r$estimate[2]-wrong_r$estimate[1]),wrong_r$p.value),
                  cbind("Marijuana use does not increase violent crime",violence_r$estimate[1],violence_r$estimate[2],(violence_r$estimate[2]-violence_r$estimate[1]),violence_r$p.value),
                  cbind("Should be legal for medical use",legmed_r$estimate[1],legmed_r$estimate[2],(legmed_r$estimate[2]-legmed_r$estimate[1]),legmed_r$p.value),
                  cbind("Not a serious problem",serious_r$estimate[1],serious_r$estimate[2],(serious_r$estimate[2]-serious_r$estimate[1]),serious_r$p.value),
                  cbind("Should be legal for recreational use",legrec_r$estimate[1],legrec_r$estimate[2],(legrec_r$estimate[2]-legrec_r$estimate[1]),legrec_r$p.value),
                  cbind("Marijuana is dangerous",danger_r$estimate[1],danger_r$estimate[2],(danger_r$estimate[2]-danger_r$estimate[1]),danger_r$p.value),
                  cbind("Actions Index",action_r$estimate[1],action_r$estimate[2],(action_r$estimate[2]-action_r$estimate[1]),action_r$p.value)
                  )

write.table(tab_ideo,file = "table_ideology.csv",sep = ",",row.names=F,col.names=F)


## ------------------- ##
#### Factor analysis ####
## ------------------- ##
library(psych)
library(GPArotation)
cor(w1[,outcomes[3:12]],use = "complete",method = "pearson")
# eigenvalues to match Stata output:
R <- cor(w1[,outcomes[3:12]],use="complete.obs")
R1 <- solve(R)
for(j in 1:ncol(R)){
      R[j,j] = R[j,j] = 1-(1/R1[j,j])
}
evs <- eigen(R)$values # should match Stata eigenvalues

# if you want to output data for Stata:
# w1.st <- w1
# for (colname in names(w1.st)) {
#       if (typeof(w1.st[[colname]]) == "character") {
#             w1.st[[colname]] <- as.factor(w1.st[[colname]])
#       }
# }
# write.dta(w1.st,"SSI_for_stata.dta",convert.factors="labels") # this will throw some errors due to length of variable values

# FA in R:
parallel <- fa.parallel(w1[,c(outcomes[3:12])], fm = 'minres', fa = 'fa')
fa <- fa(w1[,c(outcomes[3:12])],nfactors = 3,rotate = "varimax")
# fa <- fa(w1[,c(outcomes[3:12])],nfactors = 2,rotate = "varimax")
# fa <- fa(w1[,c(outcomes[3:12])],nfactors = 1,rotate = "varimax")
fa$loadings 

# append factor scores to data:
w1[,c("MR1","MR2","MR3")] <- fa$scores
# w1[,c("MR1","MR2")] <- fa$scores
# w1[,c("MR1")] <- fa$scores

## check persuasion effects on 3-factor scales:
mar_f1_e <- t.test(x=w1$MR1[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$MR1[w1$fox==1 & w1$med_pref=="Entertainment"])
mar_f1_f <- t.test(x=w1$MR1[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$MR1[w1$fox==1 & w1$med_pref=="Fox"])
mar_f1_m <- t.test(x=w1$MR1[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$MR1[w1$fox==1 & w1$med_pref=="MSNBC"])

mar_f2_e <- t.test(x=w1$MR2[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$MR2[w1$fox==1 & w1$med_pref=="Entertainment"])
mar_f2_f <- t.test(x=w1$MR2[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$MR2[w1$fox==1 & w1$med_pref=="Fox"])
mar_f2_m <- t.test(x=w1$MR2[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$MR2[w1$fox==1 & w1$med_pref=="MSNBC"])

mar_f3_e <- t.test(x=w1$MR3[w1$msnbc==1 & w1$med_pref=="Entertainment"],y=w1$MR3[w1$fox==1 & w1$med_pref=="Entertainment"])
mar_f3_f <- t.test(x=w1$MR3[w1$msnbc==1 & w1$med_pref=="Fox"],y=w1$MR3[w1$fox==1 & w1$med_pref=="Fox"])
mar_f3_m <- t.test(x=w1$MR3[w1$msnbc==1 & w1$med_pref=="MSNBC"],y=w1$MR3[w1$fox==1 & w1$med_pref=="MSNBC"])

# check reliability of single additive index:
alpha(w1[,c(outcomes[3:12])])
