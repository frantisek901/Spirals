## Replication File for:
## ``Persuading the Enemy: Estimating the Persuasive Effects of Partisan Media with the Preference-Incorporating Choice and Assignment Design"
## Justin de Benedictis-Kessner, Matthew A. Baum, Adam J. Berinsky, and Teppei Yamamoto

## ---------- ##
#### Notes: ####
## ---------- ##

# This is the third script file needed to reproduce the results from the paper
# Run the first script, ``01-survey_recodes.R" first to produce recoded survey dataset that this script needs
# Then run the second script, ``02-main_tables_figures.R" to produce tables and figures for primary results

## --------------------- ##
#### Preliminary stuff ####
## --------------------- ##

# library(descr)
# library(xtable)
# # library(tidyverse)
# library(car)
# library(lpSolve)
library(ggplot2)
# library(stargazer)
library(Cairo)
# library(nnet)

## load functions for sensitivity analyses:
source("bounds_frechet_function.R")

## --------- ##
#### Style ####
## --------- ##
'%.%' <- function(x,y) paste(x,y,sep='')

CairoFonts(regular="CMU Serif",
					 bold="CMU Serif Extra"
)

red_mit = '#A31F34'
red_light = '#A9606C'
blue_mit = '#315485'
grey_light= '#C2C0BF'
grey_dark = '#8A8B8C'
black = '#353132'


## ------------------------- ##
#### Read in recoded data: ####
## ------------------------- ##

d.raw = read.csv("MediaSSI_Dec2017_recoded.csv") # don't load with tidy read_csv or some bounds functions don't work

## set label and outcome values:
med_labels = c("Entertainment", "Fox", "MSNBC") # must be same as order of factor levels for med_choice and med_pref
J = length(med_labels)

## to run analyses for indices only:
outcomes = c(
	"mar_index",
	"actions_index"
)
outcome_labels = c(
	mar_index = "Attitudinal Index",
	actions_index = "Sharing Index"
)

## to run with all individual DVs as outcome herem, un-comment these lines:
# outcomes = c(
# 	"mar_tradeoff",
# 	"mar_econ",
# 	"mar_costmore", 
# 	"mar_fewserious", 
# 	"mar_wrong",
# 	'mar_violence',
# 	'mar_legmed',
# 	'mar_serious',
# 	'mar_legrec',
# 	"danger_mar",
# 	"actions_index",
# 	"mar_index"
# )
# outcome_labels = c(
# 	mar_tradeoff = "Addiction/crime\ntradeoff",
# 	mar_econ = "Legalization would\nmake econ better",
# 	mar_costmore = "Regulation\nworth cost", 
# 	mar_fewserious = "Legalization leads\nto fewer\nserious crimes", 
# 	mar_wrong = "Marijuana\nmorally wrong",
# 	mar_violence = "Marijuana use\nincreases\nviolent crime",
# 	mar_legmed = "Should be legal\nfor medical use",
# 	mar_serious = "Not a serious problem",
# 	mar_legrec = "Should be legal\nfor recreational use",
# 	danger_mar = "Marijuana is\ndangerous",
# 	actions_index = "Sharing index",
# 	mar_index = "Attitudinal Index"
# )

## -------------- ##
### Run bounds: ####
## -------------- ##

y.min = 0; y.max = 1

for (outcome in outcomes){
	
	set.seed(02139)
	
	cat("outcome:", outcome, '\n')
	
	output.fname = 'results_' %.% outcome %.% '.RData'
	if (file.exists(output.fname)){
		next
	}
	
	d = data.frame(S = sapply(d.raw$med_pref, function(x) ifelse(is.na(x), x, switch(x, Fox=1, MSNBC=2, Entertainment=3))),
								 A = sapply(d.raw$article_read, function(x) ifelse(is.na(x), x, switch(x, Fox=1, MSNBC=2, Entertainment=3))),
								 C = sapply(d.raw$med_choice, function(x) ifelse(is.na(x), x, switch(x, Fox=1, MSNBC=2, Entertainment=3))),
								 D = d.raw$forcedchoice
	)
	d$Y = d.raw[,outcome]
	
	## d = d[which(d.raw$vid_prob==2),] # drop all units with "Did you encounter any problems viewing this clip?" == Yes
	
	### clean data
	
	drop = which(is.na(d$S) |
							 	is.na(d$D) |
							 	is.na(d$A) |
							 	is.na(d$Y) |
							 	(is.na(d$C) & d$D==0)
	)
	if (length(drop) > 0) d = d[-drop,]
	
	# checks
	if (any(d$Y < y.min | d$Y > y.max,na.rm=T)) stop("outcome values inconsistent with given upper/lower bounds")
	all.equal(d[d$D==0,]$C,d[d$D==0,]$A) # assignment always equals choice in free condition
	all(is.na(d$C[d$D==1])) # no media choice recorded for forced condition
	!any(is.na(d[d$D==0,])) # no missing data in free condition
	!any(is.na(d[d$D==1,-which(colnames(d)=="C")])) # no missing data in forced condition, except choice
	
	
	
	## ----------- #
	## run bounds ##
	## ----------- #
	
	effects.mat = matrix(FALSE, 3, 3)
	# set up which comparison to make for treatment effect, based on med_labels (Entertainment, Fox, MSNBC)
	# here we want control = MSNBC, treat = Fox, so we do 3, 2
	effects.mat[3, 2] = TRUE  
	## effects.mat[rbind(c(3, 1),
	##                   c(2, 1),
	##                   c(3, 2))] = TRUE
	
	out = bounds.frechet(
		data = d,
		effects.mat = effects.mat,
		posterior = TRUE,
		n_dir_MC = 500,
		n_norm_MC = 10,
		sensitivity = TRUE,
		rhos = seq(0, .25, .01),
		hpd = TRUE,
		alpha = .95
	)
	
	
	
	## ---------------------- #
	## write results to file ##
	## ---------------------- #
	
	## strata_for_csv = melt(out$min_ca)
	## colnames(strata_for_csv)[3] = "ybar_min"
	## strata_for_csv$ybar_max = melt(out$max_ca)$value
	## strata_for_csv$observed = strata_for_csv$c == strata_for_csv$a
	## strata_for_csv$bounded = !strata_for_csv$observed
	## write_csv(strata_for_csv, file="./" %.% outcome %.% "_stratabounds.csv", row.names=f)
	
	effects_for_csv = out$effects
	colnames(effects_for_csv)[4:5] = c("change_ybar_min", "change_ybar_max")
	effects_for_csv$change_ybar_cilo = out$posterior$effects.ci[, "min_cilo"]
	effects_for_csv$change_ybar_cihi = out$posterior$effects.ci[, "max_cihi"]
	effects_for_csv$neither_observed = effects_for_csv$C != effects_for_csv$ctrl &
		effects_for_csv$C != effects_for_csv$treat
	write.csv(effects_for_csv, file="./" %.% outcome %.% "_effectbounds.csv",row.names = F)
	save(out, file=output.fname)
	
	cat('=====\n')
	
}



## --------------------------------------------------------------- #
## read sensitivity results back in, find where bounds cross zero ##
## --------------------------------------------------------------- #

effects.mat = matrix(FALSE, 3, 3)
# again, set up which comparison to make for treatment effect, based on med_labels (Entertainment, Fox, MSNBC)
# here we want control = MSNBC, treat = Fox, so we do 3, 2
effects.mat[3, 2] = TRUE
effects.ind = which(effects.mat, arr.ind=T)
colnames(effects.ind) = c("ctrl", "treat")

for (outcome in outcomes){
	
	load('results_' %.% outcome %.% '.RData')
	
	zero.crossings <- expand.grid(C = 1:J,
																treatment.ind = 1:nrow(effects.ind)
	)
	zero.crossings$ctrl <- effects.ind[,'ctrl'][zero.crossings$treatment.ind]
	zero.crossings$treat <- effects.ind[,'treat'][zero.crossings$treatment.ind]
	zero.crossings$treatment.ind <- NULL
	zero.crossings$min.crosses.zero <-
		zero.crossings$max.crosses.zero <- NA
	zero.crossings$min.ci.crosses.zero <-
		zero.crossings$max.ci.crosses.zero <- NA
	zero.crossings$min.becomes.flat <-
		zero.crossings$max.becomes.flat <- NA
	zero.crossings$min.ci.becomes.flat <-
		zero.crossings$max.ci.becomes.flat <- NA
	
	for (i in 1:nrow(zero.crossings)){
		
		## subset to choice/treatment of interest
		ind <- which(
			out$sensitivity$effects$C == zero.crossings$C[i] &
				out$sensitivity$effects$ctrl == zero.crossings$ctrl[i] &
				out$sensitivity$effects$treat == zero.crossings$treat[i]
		)
		
		## invert sensitivity bounds to find value of rho at which bounds cross zero
		##   (to do this, drop values in low-rho NA region and high-rho flat region)
		min.drop <- diff(c(0, out$sensitivity$effects$min[ind])) == 0
		max.drop <- diff(c(0, out$sensitivity$effects$max[ind])) == 0
		zero.crossings$min.becomes.flat[i] <-
			out$sensitivity$effects$rho[ind][
				which(min.drop)[1] - 1
				]
		zero.crossings$max.becomes.flat[i] <-
			out$sensitivity$effects$rho[ind][
				which(max.drop)[1] - 1
				]
		min.drop[is.na(min.drop)] <- TRUE
		max.drop[is.na(max.drop)] <- TRUE
		
		min.ci.drop <- diff(c(0, out$posterior$sens_effects.ci[ind, 'min_cilo'])) == 0
		max.ci.drop <- diff(c(0, out$posterior$sens_effects.ci[ind, 'max_cihi'])) == 0
		zero.crossings$min.ci.becomes.flat[i] <-
			out$sensitivity$effects$rho[ind][
				which(min.ci.drop)[1] - 1
				]
		zero.crossings$max.ci.becomes.flat[i] <-
			out$sensitivity$effects$rho[ind][
				which(max.ci.drop)[1] - 1
				]
		min.ci.drop[is.na(min.ci.drop)] <- TRUE
		max.ci.drop[is.na(max.ci.drop)] <- TRUE
		
		if (length(ind[!min.drop]) > 1){
			zero.crossings$min.crosses.zero[i] <- approx(
				x = out$sensitivity$effects$min[ind][!min.drop],
				y = out$sensitivity$effects$rho[ind][!min.drop],
				xout = 0
			)$y
		}
		if (length(ind[!min.ci.drop]) > 1){
			zero.crossings$min.ci.crosses.zero[i] <- approx(
				x = out$posterior$sens_effects.ci[ind, 'min_cilo'][!min.ci.drop],
				y = out$posterior$sens_effects.ci[ind, 'rho'][!min.ci.drop],
				xout = 0
			)$y
		}
		if (length(ind[!max.drop]) > 1){
			zero.crossings$max.crosses.zero[i] <- approx(
				x = out$sensitivity$effects$max[ind][!max.drop],
				y = out$sensitivity$effects$rho[ind][!max.drop],
				xout = 0
			)$y
		}
		if (length(ind[!max.ci.drop]) > 1){
			zero.crossings$max.ci.crosses.zero[i] <- approx(
				x = out$posterior$sens_effects.ci[ind, 'max_cihi'][!max.ci.drop],
				y = out$posterior$sens_effects.ci[ind, 'rho'][!max.ci.drop],
				xout = 0
			)$y
		}
	}
	
	write.csv(zero.crossings, file="./" %.% outcome %.% "_senscrosszero.csv",row.names = F)
	
}



## ------------------------------------------- #
## read results back in, combine for plotting ##
## ------------------------------------------- #
# clear results if already loaded:
rm(naive.all, naive.ci.all,
	 bounds.all, bounds.ci.all,
	 sens.all, sens.ci.all)

for (outcome in outcomes){
	
	load('results_' %.% outcome %.% '.RData')
	
	## merge all naive estimates together
	out$naive$effects$rho = 0  ## plot naive at left side of sens plots
	out$naive$effects$outcome = outcome
	if (exists('naive.all')){
		naive.all = rbind(naive.all, out$naive$effects)
	} else {
		naive.all = out$naive$effects
	}
	
	## merge all naive ci together
	## naive.ci = as.data.frame(out$naive.quantiles[,,"quantile_0.025"])
	## colnames(naive.ci)[colnames(naive.ci)=="point"] = "min"
	## naive.ci$max = out$naive.quantiles[,"point","quantile_0.975"]
	## naive.ci$rho = 0  ## plot naive at left side of sens plots
	naive.ci = out$posterior$naive_effects.ci
	naive.ci$rho = 0  ## plot naive at left side of sens plots
	naive.ci$outcome = outcome
	if (exists('naive.ci.all')){
		naive.ci.all = rbind(naive.ci.all, naive.ci)
	} else {
		naive.ci.all = naive.ci
	}
	
	## merge all bounds together
	out$effects$rho = .175  ## plot bounds at right side of sens plots
	out$effects$outcome = outcome
	if (exists('bounds.all')){
		bounds.all = rbind(bounds.all, out$effects)
	} else {
		bounds.all = out$effects
	}
	
	## merge all bounds ci together
	## take .025-quantile of min (implicitly) and .975-quantile of max
	## effects.ci = as.data.frame(out$effects.quantiles[,,"quantile_0.025"])
	## effects.ci$max = out$effects.quantiles[,"max","quantile_0.975"]
	effects.ci = out$posterior$effects.ci
	effects.ci$rho = .175  ## plot bounds at right side of sens plots
	effects.ci$outcome = outcome
	if (exists('bounds.ci.all')){
		bounds.ci.all = rbind(bounds.ci.all, effects.ci)
	} else {
		bounds.ci.all = effects.ci
	}
	
	## merge all sensitivity results together
	## out$sens$outcome = outcome
	out$sensitivity$effects$outcome = outcome
	if (exists('sens.all')){
		sens.all = rbind(sens.all, out$sensitivity$effects)
	} else {
		sens.all = out$sensitivity$effects
	}
	
	## merge all sensitivity ci together
	## don't plot ci when estimate undefined
	## sens.ci = as.data.frame(out$sens.quantiles[,,"quantile_0.025"])
	## sens.ci$max = out$sens.quantiles[,"max","quantile_0.975"]
	sens.ci = out$posterior$sens_effects.ci
	sens.undef.ind = which(is.na(out$sensitivity$effects$min) | is.na(out$sensitivity$effects$max))
	sens.ci$min_cilo[sens.undef.ind] = sens.ci$max_cihi[sens.undef.ind] = NA
	sens.ci$outcome = outcome
	if (exists('sens.ci.all')){
		sens.ci.all = rbind(sens.ci.all, sens.ci)
	} else {
		sens.ci.all = sens.ci
	}
	
	rm(out)
	
}

## prep labels for plotting 
naive.all$outcome <- factor(naive.all$outcome,
														levels = outcomes,
														labels = outcome_labels,
														ordered = TRUE)
naive.ci.all$outcome <- factor(naive.ci.all$outcome,
															 levels = outcomes,
															 labels = outcome_labels,
															 ordered = TRUE)
bounds.all$outcome <- factor(bounds.all$outcome,
														 levels = outcomes,
														 labels = outcome_labels,
														 ordered = TRUE)
bounds.ci.all$outcome <- factor(bounds.ci.all$outcome,
																levels = outcomes,
																labels = outcome_labels,
																ordered = TRUE)
sens.all$outcome <- factor(sens.all$outcome,
													 levels = outcomes,
													 labels = outcome_labels,
													 ordered = TRUE)
sens.ci.all$outcome <- factor(sens.ci.all$outcome,
															levels = outcomes,
															labels = outcome_labels,
															ordered = TRUE)

naive.all$C <- factor(naive.all$C,
											levels = c(1,2,3), # to re-order presentation of levels in figures
											labels =  "Prefer\n" %.% med_labels,
											ordered = TRUE)
naive.ci.all$C <- factor(naive.ci.all$C,
												 levels = c(1,2,3),
												 labels = "Prefer\n" %.% med_labels,
												 ordered = TRUE)
bounds.all$C <- factor(bounds.all$C,
											 levels = c(1,2,3),
											 labels = "Prefer\n" %.% med_labels,
											 ordered = TRUE)
bounds.ci.all$C <- factor(bounds.ci.all$C,
													levels = c(1,2,3),
													labels = "Prefer\n" %.% med_labels,
													ordered = TRUE)
sens.all$C <- factor(sens.all$C,
										 levels = c(1,2,3),
										 labels = "Prefer\n" %.% med_labels,
										 ordered = TRUE)
sens.ci.all$C <- factor(sens.ci.all$C,
												levels = c(1,2,3),
												labels = "Prefer\n" %.% med_labels,
												ordered = TRUE)

## --------------------- ##
#### Sensitivity plots ####
## --------------------- ##

# When making plots for all individual DVs, we want to limit x axis to area where 
# sensitivity analyses haven't flattened. Here, we find that max/min value for CI 
# of the bounds, plus adding a buffer of 0.01 for presentational purposes.
att_ent_maxrho <- max(c(sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Attitudinal Index" & sens.ci.all$min_cilo == min(sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Attitudinal Index")], na.rm=TRUE))][1], 
												sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Attitudinal Index" & sens.ci.all$max_cihi==max(sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Attitudinal Index")], na.rm=TRUE))][1]), na.rm=T) + 0.01

att_fox_maxrho <- max(c(sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Attitudinal Index" & sens.ci.all$min_cilo == min(sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Attitudinal Index")], na.rm=TRUE))][1], 
												sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Attitudinal Index" & sens.ci.all$max_cihi==max(sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Attitudinal Index")], na.rm=TRUE))][1]), na.rm=T) + 0.01

att_msnbc_maxrho <- max(c(sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Attitudinal Index" & sens.ci.all$min_cilo == min(sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Attitudinal Index")], na.rm=TRUE))][1],
													sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Attitudinal Index" & sens.ci.all$max_cihi==max(sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Attitudinal Index")], na.rm=TRUE))][1]), na.rm=T) + 0.01

beh_ent_maxrho <- max(c(sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Sharing Index" & sens.ci.all$min_cilo == min(sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Sharing Index")], na.rm=TRUE))][1],
												sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Sharing Index" & sens.ci.all$max_cihi==max(sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Sharing Index")], na.rm=TRUE))][1]), na.rm=T) + 0.01

beh_fox_maxrho <- max(c(sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Sharing Index" & sens.ci.all$min_cilo == min(sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Sharing Index")], na.rm=TRUE))][1], 
												sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Sharing Index" & sens.ci.all$max_cihi == max(sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Sharing Index")], na.rm=TRUE))][1]), na.rm=T) + 0.01

beh_msnbc_maxrho <- max(c(sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Sharing Index" & sens.ci.all$min_cilo == min(sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Sharing Index")], na.rm=TRUE))][1],
													sens.ci.all$rho[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Sharing Index" & sens.ci.all$max_cihi == max(sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Sharing Index")], na.rm=TRUE))][1]), na.rm=T) + 0.01

sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Attitudinal Index" & 
													 	sens.ci.all$rho >= att_ent_maxrho)] <- NA

sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Attitudinal Index" & 
													 	sens.ci.all$rho >= att_ent_maxrho)] <- NA

sens.all$min[which(sens.all$C=="Prefer\nEntertainment" & sens.all$outcome=="Attitudinal Index" & 
									 	sens.all$rho >= att_ent_maxrho)] <- NA

sens.all$max[which(sens.all$C=="Prefer\nEntertainment" & sens.all$outcome=="Attitudinal Index" & 
									 	sens.all$rho >= att_ent_maxrho)] <- NA


sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Attitudinal Index" & 
													 	sens.ci.all$rho >= att_fox_maxrho)] <- NA

sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Attitudinal Index" & 
													 	sens.ci.all$rho >= att_fox_maxrho)] <- NA

sens.all$min[which(sens.all$C=="Prefer\nFox" & sens.all$outcome=="Attitudinal Index" & 
									 	sens.all$rho >= att_fox_maxrho)] <- NA

sens.all$max[which(sens.all$C=="Prefer\nFox" & sens.all$outcome=="Attitudinal Index" & 
									 	sens.all$rho >= att_fox_maxrho)] <- NA


sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Attitudinal Index" & 
													 	sens.ci.all$rho >= att_msnbc_maxrho)] <- NA

sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Attitudinal Index" & 
													 	sens.ci.all$rho >= att_msnbc_maxrho)] <- NA

sens.all$min[which(sens.all$C=="Prefer\nMSNBC" & sens.all$outcome=="Attitudinal Index" & 
									 	sens.all$rho >= att_msnbc_maxrho)] <- NA

sens.all$max[which(sens.all$C=="Prefer\nMSNBC" & sens.all$outcome=="Attitudinal Index" & 
									 	sens.all$rho >= att_msnbc_maxrho)] <- NA

sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Sharing Index" & 
													 	sens.ci.all$rho >= beh_ent_maxrho)] <- NA

sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nEntertainment" & sens.ci.all$outcome=="Sharing Index" & 
													 	sens.ci.all$rho >= beh_ent_maxrho)] <- NA

sens.all$min[which(sens.all$C=="Prefer\nEntertainment" & sens.all$outcome=="Sharing Index" & 
									 	sens.all$rho >= beh_ent_maxrho)] <- NA

sens.all$max[which(sens.all$C=="Prefer\nEntertainment" & sens.all$outcome=="Sharing Index" & 
									 	sens.all$rho >= beh_ent_maxrho)] <- NA


sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Sharing Index" & 
													 	sens.ci.all$rho >= beh_fox_maxrho)] <- NA

sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nFox" & sens.ci.all$outcome=="Sharing Index" & 
													 	sens.ci.all$rho >= beh_fox_maxrho)] <- NA

sens.all$min[which(sens.all$C=="Prefer\nFox" & sens.all$outcome=="Sharing Index" & 
									 	sens.all$rho >= beh_fox_maxrho)] <- NA

sens.all$max[which(sens.all$C=="Prefer\nFox" & sens.all$outcome=="Sharing Index" & 
									 	sens.all$rho >= beh_fox_maxrho)] <- NA


sens.ci.all$min_cilo[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Sharing Index" & 
													 	sens.ci.all$rho >= beh_msnbc_maxrho)] <- NA

sens.ci.all$max_cihi[which(sens.ci.all$C=="Prefer\nMSNBC" & sens.ci.all$outcome=="Sharing Index" & 
													 	sens.ci.all$rho >= beh_msnbc_maxrho)] <- NA

sens.all$min[which(sens.all$C=="Prefer\nMSNBC" & sens.all$outcome=="Sharing Index" & 
									 	sens.all$rho >= beh_msnbc_maxrho)] <- NA

sens.all$max[which(sens.all$C=="Prefer\nMSNBC" & sens.all$outcome=="Sharing Index" & 
									 	sens.all$rho >= beh_msnbc_maxrho)] <- NA

## Figure 6 in color: ##
plot_sens2 <- ggplot(sens.ci.all, aes(x=rho)) +
	geom_ribbon(aes(ymin=min_cilo,ymax=max_cihi),
							data=subset(sens.ci.all,rho < Inf),
							fill=grey_light) +
	geom_ribbon(aes(ymin=min,ymax=max),
							data=subset(sens.all,rho < Inf),
							fill=grey_dark) +
	geom_hline(yintercept=0, linetype="dotted", colour=black) +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi, colour="naive"),
								data=naive.ci.all,
								width=.015, size=.5) +
	geom_point(aes(y=naive, colour="naive"),
						 data=naive.all) +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi,x=0.22, colour="bounds"),
								data=bounds.ci.all,
								width=.015, size=.5) +
	geom_errorbar(aes(ymin=min, ymax=max,x=0.22, colour="bounds"),
								data=bounds.all,
								width=.01, size=1) +
	facet_grid(outcome ~ C,scales = "free") +
	theme_bw() + 
	scale_x_continuous(breaks=seq(0, .2, .05),labels=seq(0, .2, .05),limits=c(-0.015,0.228)) +
	xlab(expression("Sensitivity parameter " * (rho))) +
	scale_y_continuous(breaks=seq(-.3, .3, .1),labels=seq.int(from=-.30, to=.30, length.out=7)) +
	# scale_y_continuous(limits=c(-.3, .3),
	#                    breaks=seq(-.3, .3, .1),
	#                    labels=c("(more\nliberal) -0.3\n","-0.2","-0.1","0","0.1","0.2","(More\nconservative)\n0.3\n\n"),
	#                    minor_breaks=seq(0,1,0.125),
	#                    # sec.axis = dup_axis(name="",
	#                    #                     breaks=seq(-.3, .3, .1),
	#                    #                     labels=c("\n\n-0.3\nLess\nwillingness\nto share","-0.2","-0.1","0","0.1","0.2","Greater\nwillingness\nto share\n0.3\n\n"))
	#                    ) +
	# annotate('text',aes(x=-Inf,y=-Inf),label=c("","","","Less\nwillingness\nto share")) +
	ylab("Expected change in outcome") +
	scale_colour_manual(values=c(naive=blue_mit, bounds=red_mit),
											guide="none") +
	theme(text=element_text(colour=black, family="CM Roman"))



fname = "sensitivity.pdf"
if (Sys.info()['sysname'] == 'Windows'){
	ggsave(fname, plot_sens2, width=8, height=8)
	embed_fonts(fname, outfile=fname)
} else {
	CairoPDF(fname, width=8, height=4)
	print(plot_sens2)
	dev.off()
}

## Figure 6 in greyscale ##
plot_sens2_grey <- ggplot(sens.ci.all, aes(x=rho)) +
	geom_ribbon(aes(ymin=min_cilo,ymax=max_cihi),
							data=subset(sens.ci.all,rho < Inf),
							fill=grey_light) +
	geom_ribbon(aes(ymin=min,ymax=max),
							data=subset(sens.all,rho < Inf),
							fill=grey_dark) +
	geom_hline(yintercept=0, linetype="dotted", colour=black) +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi, colour="naive"),
								data=naive.ci.all,
								width=.015, size=.5) +
	geom_point(aes(y=naive, colour="naive"),
						 data=naive.all) +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi,x=0.22, colour="bounds"),
								data=bounds.ci.all,
								width=.015, size=.5) +
	geom_errorbar(aes(ymin=min, ymax=max,x=0.22, colour="bounds"),
								data=bounds.all,
								width=.01, size=1) +
	facet_grid(outcome ~ C,scales = "free") +
	theme_bw() + 
	scale_x_continuous(breaks=seq(0, .2, .05),labels=seq(0, .2, .05),limits=c(-0.015,0.228)) +
	xlab(expression("Sensitivity parameter " * (rho))) +
	scale_y_continuous(breaks=seq(-.3, .3, .1),labels=seq.int(from=-.30, to=.30, length.out=7)) +
	# scale_y_continuous(limits=c(-.3, .3),
	#                    breaks=seq(-.3, .3, .1),
	#                    labels=c("(more\nliberal) -0.3\n","-0.2","-0.1","0","0.1","0.2","(More\nconservative)\n0.3\n\n"),
	#                    minor_breaks=seq(0,1,0.125),
	#                    # sec.axis = dup_axis(name="",
	#                    #                     breaks=seq(-.3, .3, .1),
	#                    #                     labels=c("\n\n-0.3\nLess\nwillingness\nto share","-0.2","-0.1","0","0.1","0.2","Greater\nwillingness\nto share\n0.3\n\n"))
	#                    ) +
	# annotate('text',aes(x=-Inf,y=-Inf),label=c("","","","Less\nwillingness\nto share")) +
	ylab("Expected change in outcome") +
	scale_colour_manual(values=c(naive=black, bounds=black),
											guide="none") +
	theme(text=element_text(colour=black, family="CM Roman"))



fname = "sensitivity_grey.pdf"
if (Sys.info()['sysname'] == 'Windows'){
	ggsave(fname, plot_sens2_grey, width=8, height=8)
	embed_fonts(fname, outfile=fname)
} else {
	CairoPDF(fname, width=8, height=4)
	print(plot_sens2_grey)
	dev.off()
}

## ----------------------- ##
#### Naive effects plots ####
## ----------------------- ##

naive.all <- na.omit(naive.all)

## Figure 3: ACTE Estimates Based on Stated Media Preferences ##
plot_naive2 = ggplot(na.omit(naive.all), aes(x=C, colour=result)) +
	geom_hline(yintercept=0, linetype="dashed") +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi, colour="naive"),
								data=na.omit(naive.ci.all),
								width=.1, size=1) +
	geom_point(aes(y=naive, colour="naive"),
						 data=na.omit(naive.all)) +
	facet_wrap(~ outcome,nrow=1) +
	xlab(NULL) +
	ylab("Treatment effect of reading\nFox rather than MSNBC") +
	scale_y_continuous(breaks=seq(-0.1,0.05,0.05),
										 labels=c("\n\n\n-0.10\n\n(More\nliberal)","-0.05","0.00","(More\nconservative)\n\n0.05\n\n\n"),
										 limits = c(-0.125,0.08),
										 sec.axis = dup_axis(name="",
										 										breaks=c(-0.1,-.05,0,0.05),
										 										labels = c("\n\n\n\n-0.10\n\n(Less\nwillingness\nto share)","-0.05","0.00","(Greater\nwillingness\nto share)\n\n0.05\n\n\n\n"))) +
	scale_colour_manual(values=c(naive=blue_mit, bounds=red_mit),
											guide="none") +
	theme(legend.position='bottom') +
	theme_bw() + 
	theme(text=element_text(colour=black, family="CM Roman",size=15))

fname = "naive_index.pdf"
if (Sys.info()['sysname'] == 'Windows'){
	ggsave(fname, plot_naive2, width=12, height=4)
	embed_fonts(fname, outfile=fname)
} else {
	CairoPDF(fname, width=8, height=3.5)
	print(plot_naive2)
	dev.off()
}


## greyscale version:
plot_naive2_grey = ggplot(na.omit(naive.all), aes(x=C, colour=result)) +
	geom_hline(yintercept=0, linetype="dashed") +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi, colour="naive"),
								data=na.omit(naive.ci.all),
								width=.1, size=1) +
	geom_point(aes(y=naive, colour="naive"),
						 data=na.omit(naive.all)) +
	facet_wrap(~ outcome,nrow=1) +
	xlab(NULL) +
	ylab("Treatment effect of reading\nFox rather than MSNBC") +
	scale_y_continuous(breaks=seq(-0.1,0.05,0.05),
										 labels=c("\n\n\n-0.10\n\n(More\nliberal)","-0.05","0.00","(More\nconservative)\n\n0.05\n\n\n"),
										 limits = c(-0.125,0.08),
										 sec.axis = dup_axis(name="",
										 										breaks=c(-0.1,-.05,0,0.05),
										 										labels = c("\n\n\n\n-0.10\n\n(Less\nwillingness\nto share)","-0.05","0.00","(Greater\nwillingness\nto share)\n\n0.05\n\n\n\n"))) +
	scale_colour_manual(values=c(naive=black, bounds=black),
											guide="none") +
	theme(legend.position='bottom') +
	theme_bw() + 
	theme(text=element_text(colour=black, family="CM Roman",size=15))

fname = "naive_grey.pdf"
if (Sys.info()['sysname'] == 'Windows'){
	ggsave(fname, plot_naive2_grey, width=12, height=4)
	embed_fonts(fname, outfile=fname)
} else {
	CairoPDF(fname, width=8, height=3.5)
	print(plot_naive2_grey)
	dev.off()
}


