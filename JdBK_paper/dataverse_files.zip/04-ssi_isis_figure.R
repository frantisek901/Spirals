## Replication File for:
## ``Persuading the Enemy: Estimating the Persuasive Effects of Partisan Media with the Preference-Incorporating Choice and Assignment Design"
## Justin de Benedictis-Kessner, Matthew A. Baum, Adam J. Berinsky, and Teppei Yamamoto

## ---------- ##
#### Notes: ####
## ---------- ##

# This is the standalone script file needed to reproduce Appendix Figure E-1.
# This script operates independently from the rest of the scripts needed to produce  
# the tables and figures for the primary results, as it uses a separate data source.
# Due to ongoing research with this extra data source, only the variables neede 
# to produce the figures used in this paper are in these survey data.

## --------------------- ##
#### Preliminary stuff ####
## --------------------- ##

library(tidyverse)
library(Cairo)


## --------- ##
#### Style ####
## --------- ##
'%.%' <- function(x,y) paste(x,y,sep='')

CairoFonts(regular="CMU Serif",
					 bold="CMU Serif Extra"
)

red_mit = '#A31F34'
red_light = '#A9606C'
blue_mit = '#315485'
grey_light= '#C2C0BF'
grey_dark = '#8A8B8C'
black = '#353132'


## ------------------------- ##
#### Read in recoded data: ####
## ------------------------- ##

## Per notes above, subsetting these survey data to those needed for this appendix figure
# d.raw = read.csv("../../../round2/full/PERLOmnibus_May2015_recoded.csv",
# 								 stringsAsFactors=FALSE)
# d.raw$att_index <- apply(d.raw[,c("isis_trade", # U.S. response to ISIS militants # dangerous threat=1, long and costly=0
# 																	"isis_succ", # U.S. likely to succeed against ISIS # 1=extremely likely, 0=extremely unlikely
# 																	"isis_troop", # U.S. sending ground troops into Iraq or Syria # completely favor=1, completely oppose=0
# 																	"isis_conf" # confidence in Obama's strategy to combat ISIS # 1=not at all confident, 0=extremely confident
# )],1,mean,na.rm=T)
# 
# data.sub <-	dplyr::select(d.raw,
# 				 med_pref,
# 				 med_choice,
# 				 video_forced,
# 				 forcedchoice,
# 				 att_index, actions_index)
# 
# write.csv(data.sub,"Media_SSI_May2015.csv",
# 					row.names = FALSE)

d.recode = read_csv("Media_SSI_May2015.csv")

med_labels = c("Entertainment", "Fox", "MSNBC") # switched to re-order columns
J = length(med_labels)

outcomes = c(
	"att_index",
	"actions_index"
)
outcome_labels = c(
	att_index = "Attitudinal Index",
	actions_index = "Sharing Index"
)

naive.all <- d.recode %>%
	filter(forcedchoice==1) %>%
	group_by(med_pref,video_forced) %>%
	summarize(att_index = mean(att_index,na.rm=T),
						actions_index = mean(actions_index,na.rm=T)
	)

naive.all <- naive.all %>%
	gather(att_index,actions_index,key = "outcome",value = "mean") %>%
	filter(video_forced != "Entertainment") %>%
	spread(key="video_forced",value = "mean") %>%
	ungroup(med_pref) %>%
	mutate(naive = Fox - MSNBC)

naive.ci.all <- d.recode %>%
	filter(forcedchoice==1) %>%
	group_by(med_pref,video_forced) %>%
	summarize(att_index = (sd(att_index,na.rm=T)/sqrt(sum(!is.na(att_index)))),
						actions_index = (sd(actions_index,na.rm=T)/sqrt(sum(!is.na(actions_index))))
	) %>%
	gather(att_index,actions_index,key = "outcome",value = "se") %>%
	filter(video_forced != "Entertainment") %>%
	spread(key="video_forced",value = "se") %>%
	left_join(naive.all[,c("med_pref","outcome","naive")],by=c("med_pref","outcome")) %>%
	ungroup(med_pref) %>%
	mutate(min_cilo = naive + qnorm(0.025)*sqrt(Fox^2 + MSNBC^2),
				 max_cihi = naive + qnorm(0.975)*sqrt(Fox^2 + MSNBC^2),
				 outcome = factor(outcome,levels = c("att_index","actions_index"),
				 								 labels = outcome_labels,
				 								 ordered=T),
				 med_pref = factor(med_pref, levels=med_labels,
				 									labels="Prefer\n" %.% med_labels,
				 									ordered=T))
naive.all <- naive.all %>%
	mutate(outcome = factor(outcome,levels = c("att_index","actions_index"),
													labels = outcome_labels,
													ordered=T),
				 med_pref = factor(med_pref, levels=med_labels,
				 									labels="Prefer\n" %.% med_labels,
				 									ordered=T))


plot_naive2 = ggplot(na.omit(naive.all), aes(x=med_pref, colour=result)) +
	geom_hline(yintercept=0, linetype="dashed") +
	geom_errorbar(aes(ymin=min_cilo, ymax=max_cihi, colour="naive"),
								data=na.omit(naive.ci.all),
								width=.1, size=1) +
	geom_point(aes(y=naive, colour="naive"),
						 data=na.omit(naive.all)) +
	facet_wrap(~ outcome,nrow=1) +
	xlab(NULL) +
	ylab("Treatment effect of watching\nFox rather than MSNBC") +
	ylab("Treatment effect of watching\nFox rather than MSNBC") +
	scale_y_continuous(breaks=seq(-0.15,0.15,0.1),
										 labels=c("\n\n\n-0.15\n\n(More\nliberal)","-0.05","0.05","(More\nconservative)\n\n0.15\n\n\n"),
										 limits = c(-0.175,0.181),
										 sec.axis = dup_axis(name="",
										 										breaks=seq(-0.15,0.15,0.1),
										 										labels = c("\n\n\n\n-0.15\n\n(Less\nwillingness\nto share)","-0.05","0.05","(Greater\nwillingness\nto share)\n\n0.15\n\n\n\n"))) +
	scale_colour_manual(values=c(naive=blue_mit, bounds=red_mit),
											guide="none") +
	theme(legend.position='bottom') +
	theme_bw() + 
	theme(text=element_text(colour=black, family="CM Roman",size=15))

fname = "naive_ssi_isis.pdf"
if (Sys.info()['sysname'] == 'Windows'){
	ggsave(fname, plot_naive2, width=12, height=4)
	embed_fonts(fname, outfile=fname)
} else {
	CairoPDF(fname, width=9, height=5)
	print(plot_naive2)
	dev.off()
}
